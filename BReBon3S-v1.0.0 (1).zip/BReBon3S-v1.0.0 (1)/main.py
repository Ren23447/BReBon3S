#!/usr/bin/env python3
"""
BReBon3S - Browser Recon & eBased Online Network Security Scanner
Version 1.0.0

A passive, informational security analysis tool for websites and APK files.
No exploitation, no installation, no active attacks.
"""

import sys
import os

# Ensure Python 3.8+
if sys.version_info < (3, 8):
    print("BReBon3S requires Python 3.8 or later.")
    sys.exit(1)

from modules import ui as UI
from modules.ui import console
from modules import website as Website
from modules import apk as APK
from modules import database as DB
from modules import reporting as Reporting
from modules import settings as Settings
from modules.utils import normalize_url, is_valid_url

from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.align import Align
from rich.rule import Rule
from rich.prompt import Prompt


# ── Website Analysis ──────────────────────────────────────────────────────────

def run_website_analysis():
    UI.section_header("WEBSITE ANALYSIS", "Passive • No exploitation • Informational only")

    UI.disclaimer_box(
        "This tool performs only passive, read-only HTTP requests and DNS lookups.\n"
        "It does not exploit vulnerabilities, test for SQL injection, or perform\n"
        "active scans. All findings are informational and not a guarantee of safety."
    )

    url = UI.prompt("Enter URL to analyse (e.g. https://example.com)").strip()
    if not url:
        UI.warn("No URL entered.")
        UI.press_enter()
        return

    if not is_valid_url(url):
        UI.error(f"'{url}' does not appear to be a valid URL.")
        UI.press_enter()
        return

    url = normalize_url(url)
    UI.info(f"Scanning: {url}")
    console.print()

    # Check local reputation DB first
    local_entry = DB.lookup_website(url)
    if local_entry:
        status = local_entry.get("status", "unknown")
        icon = DB.STATUS_ICONS.get(status, "❓")
        console.print(
            f"  {icon} [bold yellow]Local DB:[/bold yellow] This domain is marked as "
            f"[bold]{status.upper()}[/bold] in your reputation database."
        )
        if local_entry.get("notes"):
            console.print(f"     Notes: {local_entry['notes']}")
        console.print()

    # Run all analysis steps with progress
    steps = [
        ("HTTPS & TLS certificate",   Website.check_https,        [url], {}),
        ("TLS certificate details",   Website.check_tls_certificate, [Website.extract_domain(url) if hasattr(Website, 'extract_domain') else url.split("//")[-1].split("/")[0]], {}),
        ("DNS records",               Website.check_dns_records,  [url.split("//")[-1].split("/")[0]], {}),
        ("Following redirect chain",  Website.follow_redirects,   [url], {}),
    ]

    # Run the full analysis
    results = UI.spinner_task("Running passive analysis...", Website.analyze_website, url)

    _display_website_results(results)

    # Offer to save to DB
    console.print()
    if UI.confirm("Save this domain to your local reputation database?"):
        status_choice = Prompt.ask(
            "  [bold cyan]◈ Mark as[/bold cyan]",
            choices=["safe", "suspicious", "malicious"],
            default="suspicious",
        )
        notes = UI.prompt("Notes (optional)", default="")
        result = DB.add_website(url, status_choice, notes)
        if result.get("success"):
            UI.success(f"Saved '{result['entry']['domain']}' as {status_choice.upper()}")
        else:
            UI.error(result.get("error", "Failed to save"))

    UI.press_enter()


def _display_website_results(r: dict):
    from modules.utils import truncate

    score = r.get("score", 0)
    console.print()
    console.print(Rule("[bold cyan]Analysis Results[/bold cyan]", style="cyan"))

    # ── Score bar ─────────────────────────────────────────────────────────────
    UI.score_bar(score)

    # ── Score factors ─────────────────────────────────────────────────────────
    factors = r.get("score_factors", [])
    if factors:
        factor_table = Table(
            title="[bold cyan]Score Factors[/bold cyan]",
            box=box.SIMPLE_HEAVY, border_style="cyan",
            show_header=True, header_style="bold yellow", padding=(0, 1),
        )
        factor_table.add_column("Impact", width=10)
        factor_table.add_column("Finding")
        for f in factors:
            impact = f.get("impact", "info")
            icons = {"positive": "[green]✅ GOOD[/green]", "negative": "[red]❌ BAD[/red]",
                     "warn": "[yellow]⚠  WARN[/yellow]", "info": "[cyan]ℹ  INFO[/cyan]"}
            factor_table.add_row(icons.get(impact, ""), f.get("label", ""))
        console.print(factor_table)

    # ── HTTPS ─────────────────────────────────────────────────────────────────
    https_info = r.get("https", {})
    UI.status_indicator(
        "HTTPS",
        https_info.get("detail", ""),
        "good" if https_info.get("uses_https") else "bad",
    )

    # ── TLS Certificate ────────────────────────────────────────────────────────
    tls = r.get("tls", {})
    if tls.get("valid"):
        days = tls.get("days_remaining")
        days_str = f" ({days} days remaining)" if isinstance(days, int) else ""
        expiry_status = "bad" if (isinstance(days, int) and days < 0) else \
                        "warn" if (isinstance(days, int) and days < 30) else "good"
        UI.status_indicator("TLS Certificate", f"Valid — Issued by {tls.get('issuer_o', '?')}{days_str}", expiry_status)
        UI.status_indicator("  Subject CN", tls.get("subject_cn", ""), "info")
        UI.status_indicator("  Expires", tls.get("not_after", ""), "info")
    else:
        UI.status_indicator("TLS Certificate", tls.get("error", "Invalid or missing"), "bad")

    # ── Redirect chain ─────────────────────────────────────────────────────────
    fetch = r.get("fetch", {})
    redirect_count = fetch.get("redirect_count", 0)
    final_url = fetch.get("final_url", "")
    UI.status_indicator("Redirect Chain", f"{redirect_count} redirect(s) → {truncate(final_url, 70)}", "info")
    if fetch.get("cross_origin"):
        UI.status_indicator("  Cross-Origin Redirect", f"{fetch.get('start_domain')} → {fetch.get('end_domain')}", "warn")
    if fetch.get("error"):
        UI.status_indicator("Fetch Error", fetch["error"], "bad")

    # ── DNS ────────────────────────────────────────────────────────────────────
    dns_info = r.get("dns", {})
    records = dns_info.get("records", {})
    console.print()
    dns_rows = []
    for rtype, values in records.items():
        for val in values[:3]:
            dns_rows.append((rtype, truncate(val, 80)))
    if dns_rows:
        UI.list_table("DNS Records", dns_rows, ["Type", "Value"])

    if dns_info.get("has_spf"):
        UI.status_indicator("SPF Record", "Present", "good")
    else:
        UI.status_indicator("SPF Record", "Not found", "warn")

    if dns_info.get("has_dmarc"):
        UI.status_indicator("DMARC Record", "Present", "good")
    else:
        UI.status_indicator("DMARC Record", "Not found", "warn")

    # ── Security Headers ───────────────────────────────────────────────────────
    console.print()
    sec_headers = r.get("security_headers", {})
    present = sec_headers.get("present", {})
    missing = sec_headers.get("missing", [])

    if present:
        header_rows = [(h, info.get("description", "")) for h, info in present.items()]
        UI.list_table(f"Security Headers Present ({len(present)})", header_rows, ["Header", "Purpose"])

    if missing:
        missing_rows = [(m.get("header", ""), m.get("description", "")) for m in missing]
        UI.list_table(f"Missing Security Headers ({len(missing)})", missing_rows, ["Header", "Purpose"])

    # ── Page Analysis ──────────────────────────────────────────────────────────
    page = r.get("page_analysis", {})

    trackers = page.get("trackers", [])
    if trackers:
        console.print()
        tracker_rows = [(t.get("tracker", ""), truncate(t.get("src", ""), 80)) for t in trackers]
        UI.list_table(f"Third-Party Trackers Detected ({len(trackers)})", tracker_rows, ["Tracker", "Script Source"])

    ext_scripts = page.get("external_scripts", [])
    UI.status_indicator("External JS files", str(len(ext_scripts)), "info" if len(ext_scripts) < 10 else "warn")

    forms = page.get("forms", [])
    if forms:
        console.print()
        form_rows = [
            (f.get("method", ""), truncate(f.get("action", ""), 60), "YES" if f.get("has_password_field") else "no")
            for f in forms
        ]
        UI.list_table(f"HTML Forms ({len(forms)})", form_rows, ["Method", "Action URL", "Has Password Field?"])

    susp_dl = page.get("suspicious_downloads", [])
    if susp_dl:
        console.print()
        UI.warn(f"Suspicious download links found ({len(susp_dl)}):")
        for dl in susp_dl[:10]:
            console.print(f"    [red]→[/red] {truncate(dl, 100)}")

    meta_refresh = page.get("meta_refresh", [])
    if meta_refresh:
        UI.status_indicator("Meta Refresh Redirects", str(len(meta_refresh)), "warn")

    # ── Phishing Indicators ────────────────────────────────────────────────────
    phishing = r.get("phishing", [])
    if phishing:
        console.print()
        UI.warn(f"Phishing indicators detected ({len(phishing)}):")
        for p in phishing:
            console.print(f"    [yellow]⚠[/yellow]  {p}")

    # ── Reputation APIs ────────────────────────────────────────────────────────
    console.print()
    rep = r.get("reputation", {})
    vt = rep.get("virustotal", {})
    if "malicious" in vt:
        total = vt.get("malicious", 0) + vt.get("suspicious", 0) + vt.get("harmless", 0) + vt.get("undetected", 0)
        UI.status_indicator(
            "VirusTotal",
            f"{vt['malicious']} malicious / {vt.get('suspicious', 0)} suspicious / {total} engines",
            "bad" if vt["malicious"] > 0 else "warn" if vt.get("suspicious", 0) > 0 else "good",
        )
    elif "note" in vt:
        UI.status_indicator("VirusTotal", vt["note"], "info")
    elif "error" in vt:
        UI.status_indicator("VirusTotal", f"Error: {vt['error']}", "warn")


# ── APK Analysis ──────────────────────────────────────────────────────────────

def run_apk_analysis():
    UI.section_header("APK ANALYSIS", "Static • No installation • No execution • Informational only")

    UI.disclaimer_box(
        "BReBon3S analyses APK files statically — it does NOT install, execute,\n"
        "or upload your APK file. All findings are informational.\n"
        "This tool CANNOT guarantee whether an APK is safe or malicious.\n"
        "For authoritative analysis, use VirusTotal or Google Play Protect."
    )

    apk_path = UI.prompt("Enter path to APK file").strip()
    if not apk_path:
        UI.warn("No path entered.")
        UI.press_enter()
        return

    # Expand home directory
    apk_path = os.path.expanduser(apk_path)

    results = UI.spinner_task("Analysing APK...", APK.analyze_apk, apk_path)

    if "error" in results and len(results) <= 2:
        UI.error(results["error"])
        UI.press_enter()
        return

    _display_apk_results(results)

    # Offer to save hash to DB
    hashes = results.get("hashes", {})
    sha256 = hashes.get("sha256", "")
    if sha256 and UI.confirm("Save SHA-256 hash to local reputation database?"):
        status_choice = Prompt.ask(
            "  [bold cyan]◈ Mark as[/bold cyan]",
            choices=["safe", "suspicious", "malicious"],
            default="suspicious",
        )
        name = UI.prompt("App name (optional)", default=results.get("file_name", ""))
        notes = UI.prompt("Notes (optional)", default="")
        result = DB.add_apk_hash(sha256, status_choice, name, notes)
        if result.get("success"):
            UI.success(f"Saved hash as {status_choice.upper()}")
        else:
            UI.error(result.get("error", "Failed"))

    UI.press_enter()


def _display_apk_results(r: dict):
    from modules.utils import truncate

    console.print()
    console.print(Rule("[bold cyan]APK Analysis Results[/bold cyan]", style="cyan"))

    # ── File info ──────────────────────────────────────────────────────────────
    UI.key_value_table("File Information", [
        ("File Name", r.get("file_name", "")),
        ("File Size", r.get("file_size_human", "")),
        ("Valid APK/ZIP", "✅ Yes" if r.get("valid_zip") else "❌ No"),
        ("Total Files in APK", str(r.get("file_count", ""))),
        ("DEX Files", ", ".join(r.get("dex_files", []))),
        ("Has resources.arsc", "Yes" if r.get("has_resources") else "No"),
    ])

    # ── Hashes ─────────────────────────────────────────────────────────────────
    hashes = r.get("hashes", {})
    if hashes and "error" not in hashes:
        UI.key_value_table("File Hashes", [
            ("MD5",    hashes.get("md5", "")),
            ("SHA-1",  hashes.get("sha1", "")),
            ("SHA-256", hashes.get("sha256", "")),
        ])

    # ── Manifest ───────────────────────────────────────────────────────────────
    manifest = r.get("manifest", {})
    if manifest and "error" not in manifest:
        UI.key_value_table("Manifest Information", [
            ("Package Name",  manifest.get("package_name", "(not detected)")),
            ("Version Name",  manifest.get("version_name", "")),
            ("Version Code",  manifest.get("version_code", "")),
        ])
        if manifest.get("parse_note"):
            UI.info(manifest["parse_note"])

    # ── Signing ────────────────────────────────────────────────────────────────
    signing = r.get("signing", {})
    sign_status = "good" if signing.get("appears_signed") else "bad"
    UI.status_indicator(
        "APK Signed",
        "Signature files found" if signing.get("appears_signed") else "No signature files found",
        sign_status,
    )
    if signing.get("sig_files"):
        console.print(f"  [dim white]  Signature files: {', '.join(signing['sig_files'][:5])}[/dim white]")
    if signing.get("note"):
        UI.info(signing["note"])

    # ── Permissions ────────────────────────────────────────────────────────────
    permissions = manifest.get("permissions", [])
    high_risk = manifest.get("high_risk_permissions", [])

    if permissions:
        console.print()
        perm_rows = []
        for p in sorted(permissions):
            info = APK.PERMISSION_INFO.get(p, {"risk": "low", "desc": "Unknown permission"})
            risk_icon = {"high": "[red]HIGH[/red]", "medium": "[yellow]MED[/yellow]", "low": "[green]LOW[/green]"}.get(info["risk"], "")
            perm_rows.append((risk_icon, p.replace("android.permission.", ""), info["desc"]))
        UI.list_table(f"Requested Permissions ({len(permissions)})", perm_rows, ["Risk", "Permission", "What it allows"])

    if high_risk:
        console.print()
        UI.warn(f"{len(high_risk)} HIGH-RISK permission(s) requested:")
        for p in high_risk:
            info = APK.PERMISSION_INFO.get(p, {})
            console.print(f"    [red]⚠[/red] {p.replace('android.permission.', '')} — {info.get('desc', '')}")

    # ── Embedded URLs ──────────────────────────────────────────────────────────
    embedded = r.get("embedded_urls", [])
    if embedded:
        console.print()
        url_rows = [(truncate(u, 100),) for u in embedded[:25]]
        UI.list_table(f"Embedded URLs/Endpoints ({len(embedded)} found, showing up to 25)", url_rows, ["URL"])

    # ── Native libs ────────────────────────────────────────────────────────────
    native = r.get("native_libs", {})
    if native:
        console.print()
        lib_rows = []
        for arch, libs in native.items():
            for lib in libs:
                lib_rows.append((arch, lib))
        UI.list_table("Native Libraries", lib_rows, ["Architecture", "Library"])

    # ── Risk summary ───────────────────────────────────────────────────────────
    risk = r.get("risk_summary", {})
    console.print()
    if risk.get("flags"):
        UI.warn("Risk Flags:")
        for flag in risk["flags"]:
            console.print(f"    [red]❌[/red] {flag}")
    if risk.get("warnings"):
        UI.info("Warnings:")
        for warn_msg in risk["warnings"]:
            console.print(f"    [yellow]⚠[/yellow]  {warn_msg}")

    console.print()
    UI.disclaimer_box(risk.get("disclaimer", ""))


# ── Reputation Database ───────────────────────────────────────────────────────

def run_reputation_database():
    while True:
        UI.section_header("REPUTATION DATABASE", "Your personal trust database — local & private")

        stats = DB.database_stats()
        console.print(Align.center(
            f"[cyan]Websites: [white]{stats['total_websites']}[/white]  |  "
            f"APK Hashes: [white]{stats['total_apk_hashes']}[/white][/cyan]"
        ))
        console.print()

        table = Table(box=box.SIMPLE_HEAVY, border_style="cyan", show_header=False, padding=(0, 2))
        table.add_column("Key", style="bold yellow", width=5)
        table.add_column("Option", style="bold white")
        options = [
            ("1", "View / Search Websites"),
            ("2", "Add / Edit / Remove Website"),
            ("3", "View / Search APK Hashes"),
            ("4", "Add / Edit / Remove APK Hash"),
            ("5", "Export Database"),
            ("6", "Import Database"),
            ("B", "Back to Main Menu"),
        ]
        for key, name in options:
            table.add_row(f"[{key}]", name)
        console.print(Align.center(table))
        console.print()

        choice = Prompt.ask(
            "[bold cyan]  ◈ Select option[/bold cyan]",
            choices=["1","2","3","4","5","6","b","B"],
            show_choices=False,
        ).upper()

        if choice == "B":
            break
        elif choice == "1":
            _db_view_websites()
        elif choice == "2":
            _db_edit_website()
        elif choice == "3":
            _db_view_apk_hashes()
        elif choice == "4":
            _db_edit_apk_hash()
        elif choice == "5":
            _db_export()
        elif choice == "6":
            _db_import()


def _db_view_websites():
    UI.section_header("WEBSITES DATABASE")
    query = UI.prompt("Search (leave blank to show all)", default="")
    if query:
        entries = DB.search_websites(query)
    else:
        status_filter = Prompt.ask(
            "  [cyan]◈ Filter by status[/cyan]",
            choices=["all", "safe", "suspicious", "malicious"],
            default="all",
        )
        entries = DB.list_websites(None if status_filter == "all" else status_filter)

    if not entries:
        UI.info("No entries found.")
        UI.press_enter()
        return

    rows = [
        (
            DB.STATUS_ICONS.get(e.get("status", ""), ""),
            e.get("domain", ""),
            e.get("status", ""),
            e.get("notes", "")[:50],
            e.get("updated_at", "")[:10],
        )
        for e in entries
    ]
    UI.list_table(f"Websites ({len(entries)})", rows, ["", "Domain", "Status", "Notes", "Updated"])
    UI.press_enter()


def _db_edit_website():
    UI.section_header("ADD / EDIT WEBSITE")
    action = Prompt.ask(
        "  [cyan]◈ Action[/cyan]",
        choices=["add", "edit", "remove"],
        default="add",
    )

    if action == "add":
        url = UI.prompt("Website URL").strip()
        status = Prompt.ask("  [cyan]◈ Status[/cyan]", choices=["safe", "suspicious", "malicious"], default="suspicious")
        notes = UI.prompt("Notes", default="")
        result = DB.add_website(url, status, notes)
        if result.get("success"):
            UI.success(f"Saved: {result['entry']['domain']} → {status}")
        else:
            UI.error(result.get("error", "Failed"))

    elif action == "edit":
        domain = UI.prompt("Domain to edit (e.g. example.com)").strip()
        status = Prompt.ask("  [cyan]◈ New status (leave blank to keep)[/cyan]",
                            choices=["safe", "suspicious", "malicious", "keep"], default="keep")
        notes = UI.prompt("New notes (leave blank to keep)", default="__keep__")
        result = DB.edit_website(
            domain,
            status if status != "keep" else None,
            notes if notes != "__keep__" else None,
        )
        if result.get("success"):
            UI.success("Entry updated")
        else:
            UI.error(result.get("error", "Failed"))

    elif action == "remove":
        domain = UI.prompt("Domain to remove").strip()
        if UI.confirm(f"Remove '{domain}' from database?"):
            result = DB.remove_website(domain)
            if result.get("success"):
                UI.success(f"Removed: {domain}")
            else:
                UI.error(result.get("error", "Failed"))

    UI.press_enter()


def _db_view_apk_hashes():
    UI.section_header("APK HASH DATABASE")
    query = UI.prompt("Search (leave blank to show all)", default="")
    if query:
        entries = DB.search_apk_hashes(query)
    else:
        status_filter = Prompt.ask(
            "  [cyan]◈ Filter by status[/cyan]",
            choices=["all", "safe", "suspicious", "malicious"],
            default="all",
        )
        entries = DB.list_apk_hashes(None if status_filter == "all" else status_filter)

    if not entries:
        UI.info("No entries found.")
        UI.press_enter()
        return

    rows = [
        (
            DB.STATUS_ICONS.get(e.get("status", ""), ""),
            e.get("sha256", "")[:16] + "...",
            e.get("name", ""),
            e.get("status", ""),
            e.get("notes", "")[:40],
        )
        for e in entries
    ]
    UI.list_table(f"APK Hashes ({len(entries)})", rows, ["", "SHA-256 (partial)", "Name", "Status", "Notes"])
    UI.press_enter()


def _db_edit_apk_hash():
    UI.section_header("ADD / EDIT APK HASH")
    action = Prompt.ask(
        "  [cyan]◈ Action[/cyan]",
        choices=["add", "edit", "remove"],
        default="add",
    )

    if action == "add":
        sha256 = UI.prompt("SHA-256 hash (64 hex chars)").strip()
        name = UI.prompt("App name", default="")
        status = Prompt.ask("  [cyan]◈ Status[/cyan]", choices=["safe", "suspicious", "malicious"], default="suspicious")
        notes = UI.prompt("Notes", default="")
        result = DB.add_apk_hash(sha256, status, name, notes)
        if result.get("success"):
            UI.success(f"Saved hash as {status}")
        else:
            UI.error(result.get("error", "Failed"))

    elif action == "edit":
        sha256 = UI.prompt("SHA-256 hash to edit").strip()
        status = Prompt.ask("  [cyan]◈ New status[/cyan]",
                            choices=["safe", "suspicious", "malicious", "keep"], default="keep")
        name = UI.prompt("New name (blank to keep)", default="__keep__")
        notes = UI.prompt("New notes (blank to keep)", default="__keep__")
        result = DB.edit_apk_hash(
            sha256,
            status if status != "keep" else None,
            name if name != "__keep__" else None,
            notes if notes != "__keep__" else None,
        )
        if result.get("success"):
            UI.success("Entry updated")
        else:
            UI.error(result.get("error", "Failed"))

    elif action == "remove":
        sha256 = UI.prompt("SHA-256 hash to remove").strip()
        if UI.confirm(f"Remove hash '{sha256[:16]}...'?"):
            result = DB.remove_apk_hash(sha256)
            if result.get("success"):
                UI.success("Removed")
            else:
                UI.error(result.get("error", "Failed"))

    UI.press_enter()


def _db_export():
    UI.section_header("EXPORT DATABASE")
    default_path = os.path.join(os.path.expanduser("~"), "brebon3s_export.json")
    output_path = UI.prompt("Export file path", default=default_path)
    result = DB.export_database(output_path)
    if result.get("success"):
        UI.success(f"Exported {result['websites']} websites and {result['apk_hashes']} APK hashes to:\n  {result['path']}")
    else:
        UI.error(result.get("error", "Export failed"))
    UI.press_enter()


def _db_import():
    UI.section_header("IMPORT DATABASE")
    input_path = UI.prompt("Import file path").strip()
    merge = UI.confirm("Merge with existing entries? (No = replace everything)", default=True)
    if not merge:
        if not UI.confirm("⚠ This will REPLACE your entire database. Are you sure?"):
            UI.info("Import cancelled.")
            UI.press_enter()
            return
    result = DB.import_database(input_path, merge=merge)
    if result.get("success"):
        UI.success(f"Imported. Database now has {result['websites']} websites and {result['apk_hashes']} APK hashes.")
    else:
        UI.error(result.get("error", "Import failed"))
    UI.press_enter()


# ── Reporting Resources ───────────────────────────────────────────────────────

def run_reporting():
    while True:
        UI.section_header("REPORT ABUSE", "Official reporting links — BReBon3S does NOT submit reports for you")

        UI.disclaimer_box(Reporting.IMPORTANT_NOTICE)

        categories = Reporting.get_categories()
        table = Table(box=box.SIMPLE_HEAVY, border_style="cyan", show_header=False, padding=(0, 2))
        table.add_column("Key", style="bold yellow", width=4)
        table.add_column("Category", style="bold white")
        for i, cat in enumerate(categories, 1):
            table.add_row(f"[{i}]", cat)
        table.add_row("[S]", "Search resources")
        table.add_row("[B]", "Back to Main Menu")
        console.print(Align.center(table))
        console.print()

        valid_choices = [str(i) for i in range(1, len(categories)+1)] + ["s", "S", "b", "B"]
        choice = Prompt.ask(
            "[bold cyan]  ◈ Select option[/bold cyan]",
            choices=valid_choices,
            show_choices=False,
        ).upper()

        if choice == "B":
            break
        elif choice == "S":
            query = UI.prompt("Search keyword")
            results = Reporting.search_resources(query)
            if results:
                _display_reporting_resources(results, title=f"Search results for '{query}'")
            else:
                UI.info("No matching resources found.")
            UI.press_enter()
        else:
            try:
                idx = int(choice) - 1
                cat = categories[idx]
                resources = Reporting.get_resources_by_category(cat)
                _display_reporting_resources(resources, title=cat)
            except (ValueError, IndexError):
                pass
            UI.press_enter()


def _display_reporting_resources(resources: list, title: str = "Resources"):
    console.print()
    console.print(Rule(f"[bold cyan]{title}[/bold cyan]", style="cyan"))
    for res in resources:
        console.print()
        console.print(f"  [bold yellow]◈ {res['name']}[/bold yellow]")
        if res.get("url"):
            console.print(f"    [bold cyan]URL:[/bold cyan] [underline blue]{res['url']}[/underline blue]")
        if res.get("what_to_report"):
            console.print(f"    [bold white]Report:[/bold white] [white]{res['what_to_report']}[/white]")
        console.print(f"    [dim white]{res['description']}[/dim white]")


# ── Settings ──────────────────────────────────────────────────────────────────

def run_settings():
    UI.section_header("SETTINGS", "Configure API keys and preferences")

    cfg = Settings.get_settings()
    rows = []
    for key, val in cfg.items():
        help_info = Settings.get_setting_help(key)
        rows.append((help_info.get("label", key), Settings.mask_value(key, val)))
    UI.list_table("Current Configuration", rows, ["Setting", "Value"])

    console.print()
    UI.info("To edit a setting, enter its key name from the list below:")
    for key in cfg:
        help_info = Settings.get_setting_help(key)
        console.print(f"  [cyan]{key}[/cyan] — {help_info.get('description', '').split(chr(10))[0]}")

    console.print()
    key = UI.prompt("Setting key to edit (leave blank to go back)", default="")
    if not key:
        return

    help_info = Settings.get_setting_help(key)
    console.print(f"  [dim white]{help_info.get('description', '')}[/dim white]")
    new_val = UI.prompt(f"New value for '{key}'")
    result = Settings.update_setting(key, new_val)
    if result.get("success"):
        UI.success(f"Updated '{key}'")
    else:
        UI.error(result.get("error", "Failed to update"))

    UI.press_enter()


# ── Main Loop ─────────────────────────────────────────────────────────────────

def main():
    try:
        UI.print_banner()
        console.print(Align.center(
            "[dim white]BReBon3S is a passive, informational security scanner.\n"
            "It does not exploit vulnerabilities or make malicious requests.[/dim white]"
        ))
        console.print()

        while True:
            choice = UI.main_menu()

            if choice == "1":
                run_website_analysis()
            elif choice == "2":
                run_apk_analysis()
            elif choice == "3":
                run_reputation_database()
            elif choice == "4":
                run_reporting()
            elif choice == "5":
                run_settings()
            elif choice == "Q":
                console.print()
                console.print(Align.center("[bold cyan]Thank you for using BReBon3S. Stay safe.[/bold cyan]"))
                console.print()
                sys.exit(0)

    except KeyboardInterrupt:
        console.print()
        console.print("\n[bold cyan]BReBon3S exited. Stay safe.[/bold cyan]")
        sys.exit(0)


if __name__ == "__main__":
    main()
