#!/usr/bin/env bash
# BReBon3S - Installer script for Linux / macOS
# Usage: chmod +x install.sh && ./install.sh

set -e

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo ""
echo -e "${CYAN}██████╗ ██████╗ ███████╗██████╗  ██████╗ ███╗   ██╗██████╗ ███████╗${NC}"
echo -e "${CYAN}██╔══██╗██╔══██╗██╔════╝██╔══██╗██╔═══██╗████╗  ██║╚════██╗██╔════╝${NC}"
echo -e "${CYAN}██████╔╝██████╔╝█████╗  ██████╔╝██║   ██║██╔██╗ ██║ █████╔╝███████╗${NC}"
echo -e "${CYAN}██╔══██╗██╔══██╗██╔══╝  ██╔══██╗██║   ██║██║╚██╗██║ ╚═══██╗╚════██║${NC}"
echo -e "${CYAN}██████╔╝██║  ██║███████╗██████╔╝╚██████╔╝██║ ╚████║██████╔╝███████║${NC}"
echo -e "${CYAN}╚═════╝ ╚═╝  ╚═╝╚══════╝╚═════╝  ╚═════╝ ╚═╝  ╚═══╝╚═════╝ ╚══════╝${NC}"
echo ""
echo -e "${YELLOW}  Browser Recon & eBased Online Network Security Scanner${NC}"
echo -e "${YELLOW}  v1.0.0 Installer${NC}"
echo ""

# ── Check Python ──────────────────────────────────────────────────────────────
echo -e "${CYAN}[1/4] Checking Python version...${NC}"
if command -v python3 &>/dev/null; then
    PYTHON_CMD="python3"
elif command -v python &>/dev/null; then
    PYTHON_CMD="python"
else
    echo -e "${RED}ERROR: Python is not installed.${NC}"
    echo "Please install Python 3.8 or later from https://www.python.org/"
    exit 1
fi

PYTHON_VERSION=$($PYTHON_CMD --version 2>&1 | awk '{print $2}')
PYTHON_MAJOR=$(echo "$PYTHON_VERSION" | cut -d. -f1)
PYTHON_MINOR=$(echo "$PYTHON_VERSION" | cut -d. -f2)

if [ "$PYTHON_MAJOR" -lt 3 ] || { [ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 8 ]; }; then
    echo -e "${RED}ERROR: Python 3.8+ required. Found: $PYTHON_VERSION${NC}"
    exit 1
fi

echo -e "${GREEN}  ✓ Python $PYTHON_VERSION found ($PYTHON_CMD)${NC}"

# ── Check pip ─────────────────────────────────────────────────────────────────
echo -e "${CYAN}[2/4] Checking pip...${NC}"
if ! $PYTHON_CMD -m pip --version &>/dev/null; then
    echo -e "${RED}ERROR: pip is not available.${NC}"
    echo "Install pip with: $PYTHON_CMD -m ensurepip --upgrade"
    exit 1
fi
echo -e "${GREEN}  ✓ pip available${NC}"

# ── Install dependencies ──────────────────────────────────────────────────────
echo -e "${CYAN}[3/4] Installing dependencies...${NC}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if $PYTHON_CMD -m pip install --user -r requirements.txt; then
    echo -e "${GREEN}  ✓ All dependencies installed${NC}"
else
    echo -e "${YELLOW}  Trying without --user flag...${NC}"
    if $PYTHON_CMD -m pip install -r requirements.txt; then
        echo -e "${GREEN}  ✓ All dependencies installed${NC}"
    else
        echo -e "${RED}ERROR: Failed to install dependencies.${NC}"
        echo "Try manually: $PYTHON_CMD -m pip install -r requirements.txt"
        exit 1
    fi
fi

# ── Create data directory ─────────────────────────────────────────────────────
echo -e "${CYAN}[4/4] Setting up data directory...${NC}"
mkdir -p "$SCRIPT_DIR/data"
if [ ! -f "$SCRIPT_DIR/data/reputation_db.json" ]; then
    echo '{"websites": {}, "apk_hashes": {}}' > "$SCRIPT_DIR/data/reputation_db.json"
fi
echo -e "${GREEN}  ✓ Data directory ready: $SCRIPT_DIR/data/${NC}"

# ── Verify import ─────────────────────────────────────────────────────────────
echo ""
echo -e "${CYAN}Verifying application starts correctly...${NC}"
cd "$SCRIPT_DIR"
if $PYTHON_CMD -c "
import sys
sys.path.insert(0, '.')
from modules import ui, website, apk, database, reporting, settings, utils
print('All modules imported successfully.')
"; then
    echo -e "${GREEN}  ✓ Application verified${NC}"
else
    echo -e "${RED}ERROR: Import check failed. Check the error above.${NC}"
    exit 1
fi

# ── Create launcher script ────────────────────────────────────────────────────
LAUNCHER_PATH="$SCRIPT_DIR/brebon3s"
cat > "$LAUNCHER_PATH" << EOF
#!/usr/bin/env bash
cd "$SCRIPT_DIR"
$PYTHON_CMD main.py "\$@"
EOF
chmod +x "$LAUNCHER_PATH"

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║        BReBon3S installed successfully!              ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Run with: ${CYAN}$PYTHON_CMD main.py${NC}"
echo -e "  Or with:  ${CYAN}./brebon3s${NC}"
echo ""
echo -e "${YELLOW}  DISCLAIMER: BReBon3S is for informational purposes only.${NC}"
echo -e "${YELLOW}  It performs passive analysis and cannot guarantee safety.${NC}"
echo ""
