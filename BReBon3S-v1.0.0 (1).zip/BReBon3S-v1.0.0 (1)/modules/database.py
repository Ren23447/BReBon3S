"""
BReBon3S - Local Reputation Database
User-managed JSON database for personal trust markings.
"""

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .utils import DB_FILE, extract_domain, normalize_url

# ── Valid status values ───────────────────────────────────────────────────────

VALID_STATUSES = {"safe", "suspicious", "malicious"}

STATUS_ICONS = {
    "safe":       "✅",
    "suspicious": "⚠️ ",
    "malicious":  "❌",
}


# ── Database I/O ──────────────────────────────────────────────────────────────

def _load_db() -> Dict[str, Any]:
    if DB_FILE.exists():
        try:
            with open(DB_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"websites": {}, "apk_hashes": {}}


def _save_db(db: Dict[str, Any]) -> None:
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(db, f, indent=2, ensure_ascii=False)


# ── Website entries ───────────────────────────────────────────────────────────

def add_website(url: str, status: str, notes: str = "") -> Dict[str, Any]:
    """
    Add or update a website entry.
    Key is the domain (normalised).
    """
    if status not in VALID_STATUSES:
        return {"error": f"Invalid status. Choose from: {', '.join(VALID_STATUSES)}"}

    db = _load_db()
    domain = extract_domain(normalize_url(url))
    if not domain:
        return {"error": "Could not extract domain from URL"}

    entry = {
        "url": normalize_url(url),
        "domain": domain,
        "status": status,
        "notes": notes,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }

    existing = db["websites"].get(domain)
    if not existing:
        entry["added_at"] = entry["updated_at"]
    else:
        entry["added_at"] = existing.get("added_at", entry["updated_at"])

    db["websites"][domain] = entry
    _save_db(db)
    return {"success": True, "entry": entry}


def edit_website(domain: str, status: Optional[str] = None, notes: Optional[str] = None) -> Dict[str, Any]:
    db = _load_db()
    if domain not in db["websites"]:
        return {"error": f"Domain '{domain}' not found in database"}
    entry = db["websites"][domain]
    if status is not None:
        if status not in VALID_STATUSES:
            return {"error": f"Invalid status. Choose from: {', '.join(VALID_STATUSES)}"}
        entry["status"] = status
    if notes is not None:
        entry["notes"] = notes
    entry["updated_at"] = datetime.now(timezone.utc).isoformat()
    db["websites"][domain] = entry
    _save_db(db)
    return {"success": True, "entry": entry}


def remove_website(domain: str) -> Dict[str, Any]:
    db = _load_db()
    if domain not in db["websites"]:
        return {"error": f"Domain '{domain}' not found"}
    del db["websites"][domain]
    _save_db(db)
    return {"success": True, "removed": domain}


def lookup_website(url: str) -> Optional[Dict[str, Any]]:
    db = _load_db()
    domain = extract_domain(normalize_url(url))
    return db["websites"].get(domain)


def search_websites(query: str) -> List[Dict[str, Any]]:
    db = _load_db()
    q = query.lower()
    return [
        entry for entry in db["websites"].values()
        if q in entry.get("domain", "").lower()
        or q in entry.get("notes", "").lower()
        or q in entry.get("status", "").lower()
    ]


def list_websites(status_filter: Optional[str] = None) -> List[Dict[str, Any]]:
    db = _load_db()
    entries = list(db["websites"].values())
    if status_filter:
        entries = [e for e in entries if e.get("status") == status_filter]
    return sorted(entries, key=lambda e: e.get("updated_at", ""), reverse=True)


# ── APK hash entries ──────────────────────────────────────────────────────────

def add_apk_hash(sha256: str, status: str, name: str = "", notes: str = "") -> Dict[str, Any]:
    if status not in VALID_STATUSES:
        return {"error": f"Invalid status. Choose from: {', '.join(VALID_STATUSES)}"}
    sha256 = sha256.strip().lower()
    if len(sha256) != 64 or not all(c in "0123456789abcdef" for c in sha256):
        return {"error": "Invalid SHA-256 hash (must be 64 hex characters)"}

    db = _load_db()
    entry = {
        "sha256": sha256,
        "name": name,
        "status": status,
        "notes": notes,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    existing = db["apk_hashes"].get(sha256)
    entry["added_at"] = existing.get("added_at", entry["updated_at"]) if existing else entry["updated_at"]
    db["apk_hashes"][sha256] = entry
    _save_db(db)
    return {"success": True, "entry": entry}


def edit_apk_hash(sha256: str, status: Optional[str] = None, name: Optional[str] = None, notes: Optional[str] = None) -> Dict[str, Any]:
    sha256 = sha256.strip().lower()
    db = _load_db()
    if sha256 not in db["apk_hashes"]:
        return {"error": f"Hash '{sha256}' not found"}
    entry = db["apk_hashes"][sha256]
    if status is not None:
        if status not in VALID_STATUSES:
            return {"error": f"Invalid status."}
        entry["status"] = status
    if name is not None:
        entry["name"] = name
    if notes is not None:
        entry["notes"] = notes
    entry["updated_at"] = datetime.now(timezone.utc).isoformat()
    db["apk_hashes"][sha256] = entry
    _save_db(db)
    return {"success": True, "entry": entry}


def remove_apk_hash(sha256: str) -> Dict[str, Any]:
    sha256 = sha256.strip().lower()
    db = _load_db()
    if sha256 not in db["apk_hashes"]:
        return {"error": f"Hash '{sha256}' not found"}
    del db["apk_hashes"][sha256]
    _save_db(db)
    return {"success": True, "removed": sha256}


def lookup_apk_hash(sha256: str) -> Optional[Dict[str, Any]]:
    sha256 = sha256.strip().lower()
    db = _load_db()
    return db["apk_hashes"].get(sha256)


def search_apk_hashes(query: str) -> List[Dict[str, Any]]:
    db = _load_db()
    q = query.lower()
    return [
        e for e in db["apk_hashes"].values()
        if q in e.get("sha256", "").lower()
        or q in e.get("name", "").lower()
        or q in e.get("notes", "").lower()
        or q in e.get("status", "").lower()
    ]


def list_apk_hashes(status_filter: Optional[str] = None) -> List[Dict[str, Any]]:
    db = _load_db()
    entries = list(db["apk_hashes"].values())
    if status_filter:
        entries = [e for e in entries if e.get("status") == status_filter]
    return sorted(entries, key=lambda e: e.get("updated_at", ""), reverse=True)


# ── Import / Export ───────────────────────────────────────────────────────────

def export_database(output_path: str) -> Dict[str, Any]:
    db = _load_db()
    out = Path(output_path)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(db, f, indent=2, ensure_ascii=False)
    return {
        "success": True,
        "path": str(out.resolve()),
        "websites": len(db["websites"]),
        "apk_hashes": len(db["apk_hashes"]),
    }


def import_database(input_path: str, merge: bool = True) -> Dict[str, Any]:
    """
    Import a previously exported database file.
    If merge=True, entries are merged with existing data (import wins on conflicts).
    If merge=False, the database is completely replaced.
    """
    src = Path(input_path)
    if not src.exists():
        return {"error": f"File not found: {input_path}"}

    try:
        with open(src, "r", encoding="utf-8") as f:
            incoming = json.load(f)
    except Exception as e:
        return {"error": f"Failed to parse JSON: {e}"}

    if "websites" not in incoming and "apk_hashes" not in incoming:
        return {"error": "File does not appear to be a BReBon3S database export"}

    if merge:
        db = _load_db()
        db["websites"].update(incoming.get("websites", {}))
        db["apk_hashes"].update(incoming.get("apk_hashes", {}))
    else:
        db = {
            "websites": incoming.get("websites", {}),
            "apk_hashes": incoming.get("apk_hashes", {}),
        }

    _save_db(db)
    return {
        "success": True,
        "merged": merge,
        "websites": len(db["websites"]),
        "apk_hashes": len(db["apk_hashes"]),
    }


# ── Stats ─────────────────────────────────────────────────────────────────────

def database_stats() -> Dict[str, Any]:
    db = _load_db()
    websites = list(db["websites"].values())
    apks = list(db["apk_hashes"].values())

    def count_by_status(entries):
        counts = {s: 0 for s in VALID_STATUSES}
        for e in entries:
            s = e.get("status", "")
            if s in counts:
                counts[s] += 1
        return counts

    return {
        "total_websites": len(websites),
        "website_by_status": count_by_status(websites),
        "total_apk_hashes": len(apks),
        "apk_by_status": count_by_status(apks),
        "db_file": str(DB_FILE),
        "db_size_bytes": DB_FILE.stat().st_size if DB_FILE.exists() else 0,
    }
