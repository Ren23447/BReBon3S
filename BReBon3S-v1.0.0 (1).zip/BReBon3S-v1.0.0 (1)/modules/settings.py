"""
BReBon3S - Settings Module
Manage user configuration (API keys, preferences)
"""

from typing import Any, Dict
from .utils import load_config, save_config, DEFAULT_CONFIG


SETTINGS_HELP = {
    "virustotal_api_key": {
        "label": "VirusTotal API Key",
        "description": "Free tier available at https://www.virustotal.com/gui/sign-in\nUsed for URL/file reputation lookups during website analysis.",
        "sensitive": True,
    },
    "urlscan_api_key": {
        "label": "URLScan.io API Key",
        "description": "Free tier available at https://urlscan.io/user/signup\nUsed to submit URLs for visual scanning.",
        "sensitive": True,
    },
    "request_timeout": {
        "label": "HTTP Request Timeout (seconds)",
        "description": "How long to wait for server responses during website analysis.",
        "sensitive": False,
    },
    "user_agent": {
        "label": "HTTP User-Agent String",
        "description": "The User-Agent header sent during passive website analysis.",
        "sensitive": False,
    },
    "max_redirects": {
        "label": "Max Redirect Chain Length",
        "description": "Maximum number of redirects to follow when tracing a URL.",
        "sensitive": False,
    },
}


def get_settings() -> Dict[str, Any]:
    return load_config()


def update_setting(key: str, value: Any) -> Dict[str, Any]:
    if key not in DEFAULT_CONFIG:
        return {"error": f"Unknown setting: '{key}'"}
    cfg = load_config()
    # Type coercion
    expected_type = type(DEFAULT_CONFIG[key])
    try:
        if expected_type == int:
            value = int(value)
        elif expected_type == float:
            value = float(value)
        elif expected_type == bool:
            value = str(value).lower() in ("1", "true", "yes")
        else:
            value = str(value)
    except Exception:
        return {"error": f"Invalid value for '{key}'"}
    cfg[key] = value
    save_config(cfg)
    return {"success": True, "key": key, "value": value}


def reset_settings() -> Dict[str, Any]:
    save_config(dict(DEFAULT_CONFIG))
    return {"success": True, "config": DEFAULT_CONFIG}


def get_setting_help(key: str) -> Dict[str, Any]:
    return SETTINGS_HELP.get(key, {"label": key, "description": "No help available.", "sensitive": False})


def mask_value(key: str, value: Any) -> str:
    """Mask sensitive values for display."""
    info = SETTINGS_HELP.get(key, {})
    if info.get("sensitive") and value:
        val_str = str(value)
        if len(val_str) > 8:
            return val_str[:4] + "*" * (len(val_str) - 8) + val_str[-4:]
        return "****"
    return str(value) if value else "(not set)"
