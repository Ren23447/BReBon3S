"""
BReBon3S - Utility Functions
"""

import hashlib
import json
import os
import re
import socket
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import urlparse


# ── Paths ────────────────────────────────────────────────────────────────────

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
CONFIG_FILE = DATA_DIR / "config.json"
DB_FILE = DATA_DIR / "reputation_db.json"

DATA_DIR.mkdir(parents=True, exist_ok=True)


# ── Config ───────────────────────────────────────────────────────────────────

DEFAULT_CONFIG: Dict[str, Any] = {
    "virustotal_api_key": "",
    "urlscan_api_key": "",
    "request_timeout": 10,
    "user_agent": "BReBon3S/1.0.0 (security-scanner; passive-only)",
    "max_redirects": 10,
}


def load_config() -> Dict[str, Any]:
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            # Merge defaults for any missing keys
            for k, v in DEFAULT_CONFIG.items():
                cfg.setdefault(k, v)
            return cfg
        except Exception:
            pass
    return dict(DEFAULT_CONFIG)


def save_config(cfg: Dict[str, Any]) -> None:
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


# ── Hashing ──────────────────────────────────────────────────────────────────

def file_hashes(path: str) -> Dict[str, str]:
    """Compute MD5, SHA-1, and SHA-256 for a file."""
    md5 = hashlib.md5()
    sha1 = hashlib.sha1()
    sha256 = hashlib.sha256()

    with open(path, "rb") as f:
        while chunk := f.read(65536):
            md5.update(chunk)
            sha1.update(chunk)
            sha256.update(chunk)

    return {
        "md5": md5.hexdigest(),
        "sha1": sha1.hexdigest(),
        "sha256": sha256.hexdigest(),
    }


# ── URL helpers ───────────────────────────────────────────────────────────────

def normalize_url(url: str) -> str:
    """Ensure a URL has a scheme."""
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url.strip()


def extract_domain(url: str) -> str:
    """Return the netloc (domain) from a URL."""
    try:
        return urlparse(normalize_url(url)).netloc
    except Exception:
        return url


def is_valid_url(url: str) -> bool:
    try:
        parsed = urlparse(normalize_url(url))
        return bool(parsed.netloc)
    except Exception:
        return False


def resolve_ip(domain: str) -> Optional[str]:
    try:
        return socket.gethostbyname(domain)
    except Exception:
        return None


# ── Pattern matching ──────────────────────────────────────────────────────────

# Common phishing keyword patterns
PHISHING_KEYWORDS = re.compile(
    r"(paypal|apple|amazon|microsoft|google|netflix|bank|secure|account|verify"
    r"|login|signin|update|confirm|password|credential|support|helpdesk"
    r"|suspend|locked|unusual|activity|billing|refund|invoice|tax|irs|gov)",
    re.IGNORECASE,
)

SUSPICIOUS_TLD = re.compile(
    r"\.(tk|ml|ga|cf|gq|xyz|top|club|online|site|work|rest|uno|icu|cam"
    r"|click|download|zip|mov)$",
    re.IGNORECASE,
)

SUSPICIOUS_DOWNLOAD_EXTENSIONS = re.compile(
    r"\.(exe|msi|apk|bat|cmd|vbs|ps1|sh|dmg|pkg|deb|rpm|jar|scr|pif"
    r"|com|hta|wsf|cpl)(\?|$)",
    re.IGNORECASE,
)

IP_URL_PATTERN = re.compile(
    r"https?://(\d{1,3}\.){3}\d{1,3}[:/]"
)

LONG_SUBDOMAIN_PATTERN = re.compile(
    r"https?://([a-z0-9-]+\.){4,}"
)

HOMOGRAPH_CHARS = set("аеоруhcxЕОРАСе")  # Cyrillic lookalikes


def check_phishing_indicators(url: str) -> list:
    """Return a list of phishing indicator strings found in the URL."""
    indicators = []
    domain = extract_domain(url)

    if PHISHING_KEYWORDS.search(domain):
        indicators.append("Domain contains common phishing keywords")
    if SUSPICIOUS_TLD.search(domain):
        indicators.append("Uses a free or commonly-abused TLD")
    if IP_URL_PATTERN.match(url):
        indicators.append("URL uses a raw IP address instead of a domain")
    if LONG_SUBDOMAIN_PATTERN.match(url):
        indicators.append("URL has an unusually long subdomain chain")
    if any(c in domain for c in HOMOGRAPH_CHARS):
        indicators.append("Domain may contain homograph (lookalike) characters")
    if len(url) > 200:
        indicators.append("Unusually long URL (> 200 characters)")
    if url.count("-") > 5:
        indicators.append("High number of hyphens in domain/path")
    if url.count(".") > 6:
        indicators.append("High number of dots in URL")

    return indicators


def check_suspicious_downloads(hrefs: list) -> list:
    """Return hrefs that link to suspicious file types."""
    return [h for h in hrefs if SUSPICIOUS_DOWNLOAD_EXTENSIONS.search(h)]


# ── Formatting ────────────────────────────────────────────────────────────────

def truncate(text: str, max_len: int = 80) -> str:
    return text if len(text) <= max_len else text[:max_len - 3] + "..."


def format_size(size_bytes: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"
