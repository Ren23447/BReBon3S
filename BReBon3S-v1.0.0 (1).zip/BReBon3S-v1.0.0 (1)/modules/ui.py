"""
BReBon3S - UI Components
Cyberpunk terminal interface using Rich and Colorama
"""

import sys
import time
import shutil
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.live import Live
from rich.align import Align
from rich.columns import Columns
from rich.rule import Rule
from rich.prompt import Prompt, Confirm
from rich.syntax import Syntax
from rich import box
from rich.theme import Theme
import colorama
from colorama import Fore, Back, Style

colorama.init(autoreset=True)

# Custom Rich theme
CYBERPUNK_THEME = Theme({
    "info":     "cyan",
    "warn":     "bold yellow",
    "danger":   "bold red",
    "safe":     "bold green",
    "primary":  "bold cyan",
    "dim_text": "dim white",
    "border":   "cyan",
    "heading":  "bold white",
    "score_high": "bold green",
    "score_med":  "bold yellow",
    "score_low":  "bold red",
})

console = Console(theme=CYBERPUNK_THEME, highlight=False)

ASCII_LOGO = r"""
██████╗ ██████╗ ███████╗██████╗  ██████╗ ███╗   ██╗██████╗ ███████╗
██╔══██╗██╔══██╗██╔════╝██╔══██╗██╔═══██╗████╗  ██║╚════██╗██╔════╝
██████╔╝██████╔╝█████╗  ██████╔╝██║   ██║██╔██╗ ██║ █████╔╝███████╗
██╔══██╗██╔══██╗██╔══╝  ██╔══██╗██║   ██║██║╚██╗██║ ╚═══██╗╚════██║
██████╔╝██║  ██║███████╗██████╔╝╚██████╔╝██║ ╚████║██████╔╝███████║
╚═════╝ ╚═╝  ╚═╝╚══════╝╚═════╝  ╚═════╝ ╚═╝  ╚═══╝╚═════╝ ╚══════╝
"""

TAGLINE = "[ Browser Recon & eBased Online Network Security Scanner ]"
VERSION = "v1.0.0"


def get_terminal_width() -> int:
    """Return current terminal width."""
    return shutil.get_terminal_size((80, 24)).columns


def print_logo():
    """Print animated ASCII logo."""
    width = get_terminal_width()
    logo_lines = ASCII_LOGO.strip("\n").split("\n")

    console.print()
    for line in logo_lines:
        padded = line.center(width)
        console.print(f"[bold cyan]{padded}[/bold cyan]")
        time.sleep(0.04)

    console.print()
    console.print(Align.center(f"[bold yellow]{TAGLINE}[/bold yellow]"))
    console.print(Align.center(f"[dim white]{VERSION}[/dim white]"))
    console.print()


def print_banner():
    """Print the full startup banner with logo and status."""
    console.clear()
    print_logo()
    console.print(Rule(style="cyan"))
    status_cols = Columns([
        Text("⬛ PASSIVE ANALYSIS ONLY", style="bold green"),
        Text("⬛ NO MALWARE INSTALLED", style="bold green"),
        Text("⬛ LOCAL DATABASE", style="bold green"),
    ], equal=True, align="center")
    console.print(Align.center(status_cols))
    console.print(Rule(style="cyan"))
    console.print()


def main_menu() -> str:
    """Display the main menu and return the user's choice."""
    table = Table(
        title="[bold cyan]◈ MAIN MENU ◈[/bold cyan]",
        box=box.DOUBLE_EDGE,
        border_style="cyan",
        title_style="bold cyan",
        show_header=False,
        padding=(0, 2),
        min_width=60,
    )
    table.add_column("Key", style="bold yellow", width=6)
    table.add_column("Option", style="bold white")
    table.add_column("Description", style="dim white")

    options = [
        ("1", "Website Analysis",        "Passive security scan of any URL"),
        ("2", "APK Analysis",            "Inspect an Android APK file"),
        ("3", "Reputation Database",     "Manage your personal trust database"),
        ("4", "Report Abuse",            "Official reporting links & guidance"),
        ("5", "Settings",                "Configure API keys and preferences"),
        ("Q", "Quit",                    "Exit BReBon3S"),
    ]

    for key, name, desc in options:
        table.add_row(f"[{key}]", name, desc)

    console.print(Align.center(table))
    console.print()
    choice = Prompt.ask(
        "[bold cyan]  ◈ Select option[/bold cyan]",
        choices=["1", "2", "3", "4", "5", "q", "Q"],
        show_choices=False,
    )
    return choice.upper()


def section_header(title: str, subtitle: str = ""):
    """Print a section header."""
    console.print()
    console.print(Rule(f"[bold cyan]{title}[/bold cyan]", style="cyan"))
    if subtitle:
        console.print(Align.center(f"[dim white]{subtitle}[/dim white]"))
    console.print()


def info_box(title: str, content: str, style: str = "cyan"):
    """Display a bordered information box."""
    console.print(Panel(content, title=f"[bold]{title}[/bold]", border_style=style, padding=(1, 2)))


def status_indicator(label: str, value: str, status: str = "info"):
    """Print a status line with indicator."""
    icons = {"good": "✅", "bad": "❌", "warn": "⚠️ ", "info": "ℹ️ ", "unknown": "❓"}
    colors = {"good": "green", "bad": "red", "warn": "yellow", "info": "cyan", "unknown": "dim white"}
    icon = icons.get(status, "•")
    color = colors.get(status, "white")
    console.print(f"  {icon} [bold {color}]{label}:[/bold {color}] [white]{value}[/white]")


def score_bar(score: int, label: str = "Safety Score"):
    """Display a visual score bar."""
    bar_width = 40
    filled = int((score / 100) * bar_width)
    empty = bar_width - filled

    if score >= 70:
        color = "green"
        rating = "LOW RISK"
    elif score >= 40:
        color = "yellow"
        rating = "MODERATE RISK"
    else:
        color = "red"
        rating = "HIGH RISK"

    bar = f"[{color}]{'█' * filled}[/{color}][dim white]{'░' * empty}[/dim white]"
    console.print()
    console.print(f"  [bold white]{label}:[/bold white]")
    console.print(f"  {bar} [bold {color}]{score}/100 — {rating}[/bold {color}]")
    console.print()


def spinner_task(description: str, task_fn, *args, **kwargs):
    """Run a task with a spinner animation."""
    with Progress(
        SpinnerColumn(spinner_name="dots", style="cyan"),
        TextColumn("[bold cyan]{task.description}"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(description, total=None)
        result = task_fn(*args, **kwargs)
    return result


def multi_step_progress(steps: list):
    """
    Run multiple steps with a progress bar.
    `steps` is a list of (description, callable, args, kwargs) tuples.
    Returns list of results.
    """
    results = []
    with Progress(
        SpinnerColumn(spinner_name="dots12", style="cyan"),
        TextColumn("[bold cyan]{task.description}"),
        BarColumn(bar_width=30, style="cyan", complete_style="green"),
        TextColumn("[bold white]{task.percentage:>3.0f}%[/bold white]"),
        console=console,
    ) as progress:
        task_id = progress.add_task("Scanning...", total=len(steps))
        for desc, fn, fn_args, fn_kwargs in steps:
            progress.update(task_id, description=f"[cyan]{desc}[/cyan]")
            try:
                result = fn(*fn_args, **fn_kwargs)
            except Exception as e:
                result = {"error": str(e)}
            results.append(result)
            progress.advance(task_id)
    return results


def key_value_table(title: str, rows: list, border_style: str = "cyan"):
    """Render a two-column key/value table."""
    table = Table(
        title=f"[bold cyan]{title}[/bold cyan]",
        box=box.SIMPLE_HEAVY,
        border_style=border_style,
        show_header=True,
        header_style="bold yellow",
        padding=(0, 1),
    )
    table.add_column("Field", style="bold white", min_width=24)
    table.add_column("Value", style="white")

    for key, val in rows:
        table.add_row(str(key), str(val))

    console.print(table)


def list_table(title: str, items: list, columns: list, border_style: str = "cyan"):
    """Render a multi-column list table."""
    table = Table(
        title=f"[bold cyan]{title}[/bold cyan]",
        box=box.SIMPLE_HEAVY,
        border_style=border_style,
        show_header=True,
        header_style="bold yellow",
        padding=(0, 1),
    )
    for col in columns:
        table.add_column(col, style="white")
    for row in items:
        table.add_row(*[str(c) for c in row])
    console.print(table)


def confirm(question: str, default: bool = False) -> bool:
    """Ask a yes/no question."""
    return Confirm.ask(f"[bold yellow]  ◈ {question}[/bold yellow]", default=default)


def prompt(question: str, default: str = "") -> str:
    """Ask for text input."""
    return Prompt.ask(f"[bold cyan]  ◈ {question}[/bold cyan]", default=default)


def press_enter():
    """Wait for the user to press Enter."""
    console.print()
    Prompt.ask("[dim white]  Press Enter to continue[/dim white]", default="")
    console.print()


def warn(message: str):
    """Print a warning message."""
    console.print(f"[bold yellow]  ⚠️  {message}[/bold yellow]")


def error(message: str):
    """Print an error message."""
    console.print(f"[bold red]  ❌  {message}[/bold red]")


def success(message: str):
    """Print a success message."""
    console.print(f"[bold green]  ✅  {message}[/bold green]")


def info(message: str):
    """Print an informational message."""
    console.print(f"[cyan]  ℹ️   {message}[/cyan]")


def disclaimer_box(text: str):
    """Print a styled disclaimer box."""
    console.print(Panel(
        f"[bold yellow]{text}[/bold yellow]",
        title="[bold red]⚠ DISCLAIMER[/bold red]",
        border_style="red",
        padding=(1, 2),
    ))
