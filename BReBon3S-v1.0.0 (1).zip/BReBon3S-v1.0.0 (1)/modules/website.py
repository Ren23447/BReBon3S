"""
BReBon3S - Website Analysis Module
Passive security analysis of URLs (no active exploitation)
"""

import re
import socket
import ssl
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin, urlparse

import dns.resolver
import requests
from bs4 import BeautifulSoup

# lxml is optional — use it when available for speed, fall back to html.parser
try:
    import lxml  # noqa: F401
    _BS4_PARSER = "lxml"
except ImportError:
    _BS4_PARSER = "html.parser"

from .utils import (
    check_phishing_indicators,
    check_suspicious_downloads,
    extract_domain,
    load_config,
    normalize_url,
    truncate,
)


# ── Security headers that indicate good hygiene ───────────────────────────────

SECURITY_HEADERS = {
    "Strict-Transport-Security": "HSTS — forces HTTPS connections",
    "Content-Security-Policy": "CSP — restricts what resources can load",
    "X-Frame-Options": "Prevents clickjacking via iframes",
    "X-Content-Type-Options": "Prevents MIME-type sniffing",
    "Referrer-Policy": "Controls referrer information leakage",
    "Permissions-Policy": "Controls browser feature access",
    "X-XSS-Protection": "Legacy XSS filter (older browsers)",
    "Expect-CT": "Certificate Transparency enforcement",
}

# Known third-party tracker domains
TRACKER_DOMAINS = {
    "google-analytics.com", "googletagmanager.com", "doubleclick.net",
    "facebook.net", "connect.facebook.net", "analytics.twitter.com",
    "ads.twitter.com", "linkedin.com/px", "bat.bing.com",
    "hotjar.com", "clarity.ms", "mixpanel.com", "segment.com",
    "amplitude.com", "heap.io", "fullstory.com", "logrocket.com",
    "mouseflow.com", "crazyegg.com", "optimizely.com",
    "quantserve.com", "scorecardresearch.com", "comscore.com",
}

USER_AGENT = "BReBon3S/1.0.0 (security-scanner; passive-only)"


# ── Individual checks ─────────────────────────────────────────────────────────

def check_https(url: str) -> Dict[str, Any]:
    parsed = urlparse(normalize_url(url))
    is_https = parsed.scheme == "https"
    return {
        "uses_https": is_https,
        "scheme": parsed.scheme,
        "detail": "Site uses HTTPS encryption" if is_https else "Site uses unencrypted HTTP",
    }


def check_tls_certificate(domain: str, timeout: int = 10) -> Dict[str, Any]:
    try:
        ctx = ssl.create_default_context()
        with ctx.wrap_socket(
            socket.create_connection((domain, 443), timeout=timeout),
            server_hostname=domain,
        ) as sock:
            cert = sock.getpeercert()

        subject = dict(x[0] for x in cert.get("subject", []))
        issuer = dict(x[0] for x in cert.get("issuer", []))
        not_before_str = cert.get("notBefore", "")
        not_after_str = cert.get("notAfter", "")

        # Parse expiry
        try:
            not_after = datetime.strptime(not_after_str, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
            days_left = (not_after - datetime.now(timezone.utc)).days
            expired = days_left < 0
        except Exception:
            days_left = None
            expired = None

        san = []
        for ext in cert.get("subjectAltName", []):
            san.append(ext[1])

        return {
            "valid": True,
            "subject_cn": subject.get("commonName", "Unknown"),
            "issuer_o": issuer.get("organizationName", "Unknown"),
            "issuer_cn": issuer.get("commonName", "Unknown"),
            "not_before": not_before_str,
            "not_after": not_after_str,
            "days_remaining": days_left,
            "expired": expired,
            "san": san[:10],
            "version": cert.get("version", "Unknown"),
        }
    except ssl.SSLCertVerificationError as e:
        return {"valid": False, "error": f"Certificate verification failed: {e}"}
    except ConnectionRefusedError:
        return {"valid": False, "error": "Port 443 refused — no HTTPS listener"}
    except Exception as e:
        return {"valid": False, "error": str(e)}


def check_dns_records(domain: str) -> Dict[str, Any]:
    records: Dict[str, List[str]] = {}
    record_types = ["A", "AAAA", "MX", "NS", "TXT", "CNAME"]

    for rtype in record_types:
        try:
            answers = dns.resolver.resolve(domain, rtype, raise_on_no_answer=False)
            records[rtype] = [r.to_text() for r in answers]
        except dns.resolver.NXDOMAIN:
            records["NXDOMAIN"] = ["Domain does not exist"]
            break
        except Exception:
            pass

    # Check for SPF in TXT records
    spf = any("v=spf1" in r for r in records.get("TXT", []))
    dmarc_domain = f"_dmarc.{domain}"
    try:
        dmarc_answers = dns.resolver.resolve(dmarc_domain, "TXT", raise_on_no_answer=False)
        dmarc = any("v=DMARC1" in r.to_text() for r in dmarc_answers)
    except Exception:
        dmarc = False

    return {"records": records, "has_spf": spf, "has_dmarc": dmarc}


def follow_redirects(url: str, timeout: int = 10, max_redirects: int = 10) -> Dict[str, Any]:
    cfg = load_config()
    headers = {"User-Agent": cfg.get("user_agent", USER_AGENT)}
    chain = []
    current = normalize_url(url)

    try:
        resp = requests.get(
            current,
            headers=headers,
            allow_redirects=True,
            timeout=timeout,
            stream=False,
        )
        # Build chain from response history
        for r in resp.history:
            chain.append({
                "url": r.url,
                "status": r.status_code,
                "location": r.headers.get("Location", ""),
            })
        chain.append({"url": resp.url, "status": resp.status_code, "location": ""})

        # Cross-origin check
        start_domain = extract_domain(url)
        end_domain = extract_domain(resp.url)
        cross_origin = start_domain != end_domain

        return {
            "final_url": resp.url,
            "status_code": resp.status_code,
            "redirect_count": len(resp.history),
            "chain": chain,
            "cross_origin": cross_origin,
            "start_domain": start_domain,
            "end_domain": end_domain,
            "headers": dict(resp.headers),
            "response_time_ms": int(resp.elapsed.total_seconds() * 1000),
            "content": resp.text[:200000],  # cap at 200 KB
        }
    except requests.exceptions.SSLError as e:
        return {"error": f"SSL error: {e}", "final_url": url}
    except requests.exceptions.ConnectionError as e:
        return {"error": f"Connection error: {e}", "final_url": url}
    except requests.exceptions.Timeout:
        return {"error": "Request timed out", "final_url": url}
    except Exception as e:
        return {"error": str(e), "final_url": url}


def check_security_headers(headers: dict) -> Dict[str, Any]:
    present = {}
    missing = []
    for h, desc in SECURITY_HEADERS.items():
        if h.lower() in {k.lower() for k in headers}:
            val = next((v for k, v in headers.items() if k.lower() == h.lower()), "")
            present[h] = {"value": truncate(val, 120), "description": desc}
        else:
            missing.append({"header": h, "description": desc})

    score_deduction = len(missing) * 5
    return {"present": present, "missing": missing, "deduction": score_deduction}


def check_trackers_and_scripts(html: str, base_url: str) -> Dict[str, Any]:
    try:
        soup = BeautifulSoup(html, _BS4_PARSER)
    except Exception:
        return {"external_scripts": [], "trackers": [], "forms": [], "links": []}

    # External scripts
    external_scripts = []
    for tag in soup.find_all("script", src=True):
        src = tag.get("src", "")
        if src.startswith("http") or src.startswith("//"):
            external_scripts.append(src)

    # Tracker detection
    trackers = []
    for src in external_scripts:
        for tracker in TRACKER_DOMAINS:
            if tracker in src:
                trackers.append({"tracker": tracker, "src": truncate(src, 100)})
                break

    # Iframes
    iframes = [truncate(tag.get("src", ""), 100) for tag in soup.find_all("iframe", src=True)]

    # Forms
    forms = []
    for form in soup.find_all("form"):
        action = form.get("action", "")
        method = form.get("method", "GET").upper()
        inputs = [i.get("type", "text") for i in form.find_all("input")]
        has_password = "password" in inputs
        action_full = urljoin(base_url, action) if action else "(same page)"
        forms.append({
            "action": truncate(action_full, 100),
            "method": method,
            "has_password_field": has_password,
            "input_types": inputs,
        })

    # Hrefs — look for suspicious downloads
    hrefs = [a.get("href", "") for a in soup.find_all("a", href=True)]
    suspicious_dl = check_suspicious_downloads(hrefs)

    # Meta redirects
    meta_refresh = []
    for tag in soup.find_all("meta", attrs={"http-equiv": re.compile(r"refresh", re.I)}):
        meta_refresh.append(tag.get("content", ""))

    return {
        "external_scripts": external_scripts[:30],
        "trackers": trackers,
        "iframes": iframes[:10],
        "forms": forms,
        "suspicious_downloads": suspicious_dl[:20],
        "meta_refresh": meta_refresh,
    }


def check_reputation_apis(url: str) -> Dict[str, Any]:
    cfg = load_config()
    results = {}

    # VirusTotal (if API key provided)
    vt_key = cfg.get("virustotal_api_key", "")
    if vt_key:
        try:
            import base64
            url_id = base64.urlsafe_b64encode(url.encode()).decode().rstrip("=")
            resp = requests.get(
                f"https://www.virustotal.com/api/v3/urls/{url_id}",
                headers={"x-apikey": vt_key},
                timeout=10,
            )
            if resp.status_code == 200:
                data = resp.json()
                stats = data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
                results["virustotal"] = {
                    "malicious": stats.get("malicious", 0),
                    "suspicious": stats.get("suspicious", 0),
                    "harmless": stats.get("harmless", 0),
                    "undetected": stats.get("undetected", 0),
                }
            else:
                results["virustotal"] = {"error": f"HTTP {resp.status_code}"}
        except Exception as e:
            results["virustotal"] = {"error": str(e)}
    else:
        results["virustotal"] = {"note": "No API key configured — skipped"}

    # URLScan.io (if API key provided)
    us_key = cfg.get("urlscan_api_key", "")
    if us_key:
        try:
            resp = requests.post(
                "https://urlscan.io/api/v1/scan/",
                json={"url": url, "visibility": "private"},
                headers={"API-Key": us_key, "Content-Type": "application/json"},
                timeout=10,
            )
            if resp.status_code == 200:
                data = resp.json()
                results["urlscan"] = {
                    "uuid": data.get("uuid", ""),
                    "result_url": data.get("result", ""),
                    "note": "Scan submitted — check result URL in ~30 seconds",
                }
            else:
                results["urlscan"] = {"error": f"HTTP {resp.status_code}"}
        except Exception as e:
            results["urlscan"] = {"error": str(e)}
    else:
        results["urlscan"] = {"note": "No API key configured — skipped"}

    return results


# ── Main analysis entry point ─────────────────────────────────────────────────

def analyze_website(url: str) -> Dict[str, Any]:
    """
    Run a full passive analysis of the given URL.
    Returns a dict with all findings and an overall safety score.
    """
    cfg = load_config()
    timeout = cfg.get("request_timeout", 10)
    url = normalize_url(url)
    domain = extract_domain(url)

    results: Dict[str, Any] = {
        "url": url,
        "domain": domain,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    # 1. HTTPS check
    results["https"] = check_https(url)

    # 2. TLS certificate
    results["tls"] = check_tls_certificate(domain, timeout=timeout)

    # 3. DNS records
    results["dns"] = check_dns_records(domain)

    # 4. Follow redirects + fetch page
    fetch = follow_redirects(url, timeout=timeout)
    results["fetch"] = {k: v for k, v in fetch.items() if k != "content"}

    if "error" not in fetch:
        html_content = fetch.get("content", "")
        response_headers = fetch.get("headers", {})

        # 5. Security headers
        results["security_headers"] = check_security_headers(response_headers)

        # 6. Tracker / script analysis
        results["page_analysis"] = check_trackers_and_scripts(html_content, fetch.get("final_url", url))

        # 7. Phishing indicators (on final URL)
        results["phishing"] = check_phishing_indicators(fetch.get("final_url", url))
    else:
        results["security_headers"] = {"present": {}, "missing": list(SECURITY_HEADERS.keys()), "deduction": 40}
        results["page_analysis"] = {}
        results["phishing"] = []

    # 8. Reputation APIs
    results["reputation"] = check_reputation_apis(url)

    # ── Scoring ───────────────────────────────────────────────────────────────
    score = 100

    if not results["https"]["uses_https"]:
        score -= 25

    tls = results["tls"]
    if not tls.get("valid"):
        score -= 20
    elif tls.get("expired"):
        score -= 15
    elif isinstance(tls.get("days_remaining"), int) and tls["days_remaining"] < 14:
        score -= 10

    score -= results["security_headers"].get("deduction", 0)

    phishing_hits = len(results.get("phishing", []))
    score -= phishing_hits * 12

    page = results.get("page_analysis", {})
    score -= len(page.get("trackers", [])) * 2
    score -= len(page.get("suspicious_downloads", [])) * 8
    score -= len(page.get("meta_refresh", [])) * 5

    if results["fetch"].get("cross_origin"):
        score -= 5
    if results["fetch"].get("redirect_count", 0) > 3:
        score -= 5

    vt = results["reputation"].get("virustotal", {})
    if isinstance(vt.get("malicious"), int) and vt["malicious"] > 0:
        score -= 30
    elif isinstance(vt.get("suspicious"), int) and vt["suspicious"] > 0:
        score -= 15

    results["score"] = max(0, min(100, score))
    results["score_factors"] = _build_score_factors(results)

    return results


def _build_score_factors(r: Dict[str, Any]) -> List[Dict[str, str]]:
    factors = []

    if r["https"]["uses_https"]:
        factors.append({"label": "Uses HTTPS", "impact": "positive"})
    else:
        factors.append({"label": "No HTTPS", "impact": "negative"})

    tls = r.get("tls", {})
    if tls.get("valid"):
        days = tls.get("days_remaining")
        if isinstance(days, int) and days < 14:
            factors.append({"label": f"TLS cert expires in {days} days", "impact": "negative"})
        else:
            factors.append({"label": "Valid TLS certificate", "impact": "positive"})
    else:
        factors.append({"label": "Invalid or missing TLS certificate", "impact": "negative"})

    missing_hdrs = r.get("security_headers", {}).get("missing", [])
    if missing_hdrs:
        factors.append({"label": f"{len(missing_hdrs)} security header(s) missing", "impact": "negative"})

    for pi in r.get("phishing", []):
        factors.append({"label": pi, "impact": "negative"})

    trackers = r.get("page_analysis", {}).get("trackers", [])
    if trackers:
        factors.append({"label": f"{len(trackers)} third-party tracker(s) detected", "impact": "warn"})

    susp_dl = r.get("page_analysis", {}).get("suspicious_downloads", [])
    if susp_dl:
        factors.append({"label": f"{len(susp_dl)} suspicious download link(s)", "impact": "negative"})

    vt = r.get("reputation", {}).get("virustotal", {})
    if isinstance(vt.get("malicious"), int) and vt["malicious"] > 0:
        factors.append({"label": f"VirusTotal: {vt['malicious']} engine(s) flagged as malicious", "impact": "negative"})

    return factors
