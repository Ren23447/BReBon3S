"""
BReBon3S - APK Analysis Module
Informational static analysis of Android APK files.
No execution, no installation, no network calls to third parties.
"""

import re
import struct
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

from .utils import file_hashes, truncate

# ── Android permission descriptions ──────────────────────────────────────────

PERMISSION_INFO: Dict[str, Dict[str, str]] = {
    "android.permission.READ_CONTACTS":          {"risk": "medium", "desc": "Read your contact list"},
    "android.permission.WRITE_CONTACTS":         {"risk": "medium", "desc": "Modify your contacts"},
    "android.permission.READ_CALL_LOG":          {"risk": "high",   "desc": "Read call history"},
    "android.permission.WRITE_CALL_LOG":         {"risk": "high",   "desc": "Modify call history"},
    "android.permission.PROCESS_OUTGOING_CALLS": {"risk": "high",   "desc": "Intercept outgoing calls"},
    "android.permission.READ_SMS":               {"risk": "high",   "desc": "Read SMS messages"},
    "android.permission.SEND_SMS":               {"risk": "high",   "desc": "Send SMS messages"},
    "android.permission.RECEIVE_SMS":            {"risk": "high",   "desc": "Receive SMS messages"},
    "android.permission.CAMERA":                 {"risk": "medium", "desc": "Access device camera"},
    "android.permission.RECORD_AUDIO":           {"risk": "medium", "desc": "Record microphone audio"},
    "android.permission.ACCESS_FINE_LOCATION":   {"risk": "medium", "desc": "Precise GPS location"},
    "android.permission.ACCESS_COARSE_LOCATION": {"risk": "low",    "desc": "Approximate location"},
    "android.permission.ACCESS_BACKGROUND_LOCATION": {"risk": "high", "desc": "Background location access"},
    "android.permission.READ_EXTERNAL_STORAGE":  {"risk": "low",    "desc": "Read files on storage"},
    "android.permission.WRITE_EXTERNAL_STORAGE": {"risk": "medium", "desc": "Write files to storage"},
    "android.permission.MANAGE_EXTERNAL_STORAGE":{"risk": "high",   "desc": "Manage all files (powerful)"},
    "android.permission.INTERNET":               {"risk": "low",    "desc": "Access the internet"},
    "android.permission.USE_BIOMETRIC":          {"risk": "medium", "desc": "Use biometric authentication"},
    "android.permission.USE_FINGERPRINT":        {"risk": "medium", "desc": "Use fingerprint sensor"},
    "android.permission.BLUETOOTH":              {"risk": "low",    "desc": "Connect via Bluetooth"},
    "android.permission.BLUETOOTH_ADMIN":        {"risk": "medium", "desc": "Manage Bluetooth settings"},
    "android.permission.BLUETOOTH_SCAN":         {"risk": "medium", "desc": "Scan for Bluetooth devices"},
    "android.permission.NFC":                    {"risk": "medium", "desc": "Use NFC chip"},
    "android.permission.READ_PHONE_STATE":       {"risk": "medium", "desc": "Read device & call state"},
    "android.permission.READ_PHONE_NUMBERS":     {"risk": "medium", "desc": "Read phone numbers"},
    "android.permission.CALL_PHONE":             {"risk": "high",   "desc": "Make phone calls"},
    "android.permission.GET_ACCOUNTS":           {"risk": "medium", "desc": "Access account list"},
    "android.permission.AUTHENTICATE_ACCOUNTS":  {"risk": "high",   "desc": "Authenticate with accounts"},
    "android.permission.SYSTEM_ALERT_WINDOW":    {"risk": "high",   "desc": "Draw over other apps (overlay)"},
    "android.permission.RECEIVE_BOOT_COMPLETED": {"risk": "medium", "desc": "Start on device boot"},
    "android.permission.BIND_DEVICE_ADMIN":      {"risk": "high",   "desc": "Device administrator privileges"},
    "android.permission.INSTALL_PACKAGES":       {"risk": "high",   "desc": "Install other APKs"},
    "android.permission.REQUEST_INSTALL_PACKAGES":{"risk": "medium","desc": "Request app installs"},
    "android.permission.FOREGROUND_SERVICE":     {"risk": "low",    "desc": "Run persistent foreground service"},
    "android.permission.WAKE_LOCK":              {"risk": "low",    "desc": "Prevent CPU from sleeping"},
    "android.permission.VIBRATE":                {"risk": "low",    "desc": "Control device vibration"},
    "android.permission.CHANGE_NETWORK_STATE":   {"risk": "medium", "desc": "Change network connectivity"},
    "android.permission.ACCESS_WIFI_STATE":      {"risk": "low",    "desc": "Read Wi-Fi connection info"},
    "android.permission.CHANGE_WIFI_STATE":      {"risk": "medium", "desc": "Change Wi-Fi settings"},
    "android.permission.QUERY_ALL_PACKAGES":     {"risk": "medium", "desc": "See all installed apps"},
    "android.permission.READ_MEDIA_IMAGES":      {"risk": "medium", "desc": "Read images on device"},
    "android.permission.READ_MEDIA_VIDEO":       {"risk": "medium", "desc": "Read videos on device"},
    "android.permission.READ_MEDIA_AUDIO":       {"risk": "medium", "desc": "Read audio on device"},
}

HIGH_RISK_PERMISSIONS = {k for k, v in PERMISSION_INFO.items() if v["risk"] == "high"}

# ── URL / domain extraction patterns ─────────────────────────────────────────

URL_PATTERN = re.compile(
    rb"https?://[a-zA-Z0-9\-._~:/?#\[\]@!$&'()*+,;=%]+"
)
DOMAIN_PATTERN = re.compile(
    rb"[a-zA-Z0-9\-]{2,63}\.[a-zA-Z]{2,6}(?:\.[a-zA-Z]{2,3})?"
)

# ── APK parsing helpers ───────────────────────────────────────────────────────

def _parse_manifest_xml(data: bytes) -> Dict[str, Any]:
    """
    Very lightweight binary XML (AXML) parser.
    Extracts readable strings — does NOT fully decode Android binary XML.
    For a complete parse, tools like `aapt` or `apktool` are needed.
    """
    strings = []
    # Binary XML starts with magic 0x00080003
    if len(data) < 8 or data[:4] != b'\x03\x00\x08\x00':
        return {"raw_parse": False, "strings": []}

    try:
        # String pool chunk starts at offset 8
        chunk_type = struct.unpack_from('<H', data, 8)[0]
        if chunk_type == 0x0001:  # STRING_POOL_TYPE
            chunk_size = struct.unpack_from('<I', data, 12)[0]
            string_count = struct.unpack_from('<I', data, 16)[0]
            strings_start_offset = struct.unpack_from('<I', data, 28)[0]

            base = 8 + 28  # start of offsets array
            for i in range(min(string_count, 2000)):
                try:
                    offset = struct.unpack_from('<I', data, base + i * 4)[0]
                    str_offset = 8 + strings_start_offset + offset
                    str_len = struct.unpack_from('<H', data, str_offset)[0]
                    raw = data[str_offset + 2: str_offset + 2 + str_len * 2]
                    decoded = raw.decode('utf-16-le', errors='ignore').rstrip('\x00')
                    if decoded and len(decoded) > 1:
                        strings.append(decoded)
                except Exception:
                    pass
    except Exception:
        pass

    return {"raw_parse": True, "strings": strings}


def _extract_permissions(strings: List[str]) -> List[str]:
    return [s for s in strings if "android.permission." in s or ".permission." in s]


def _extract_package_name(strings: List[str]) -> Optional[str]:
    for s in strings:
        if re.match(r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){1,8}$', s) and len(s) > 5:
            return s
    return None


def _extract_version_info(strings: List[str]) -> Dict[str, str]:
    version_name = ""
    version_code = ""
    for s in strings:
        if re.match(r'^\d+\.\d+[\.\d]*$', s) and not version_name:
            version_name = s
        if re.match(r'^\d{1,10}$', s) and not version_code:
            version_code = s
    return {"version_name": version_name, "version_code": version_code}


def _extract_embedded_urls(file_bytes: bytes) -> List[str]:
    matches = URL_PATTERN.findall(file_bytes)
    urls = list({m.decode('ascii', errors='ignore') for m in matches})
    return urls[:100]


def _extract_domains(strings: List[str]) -> List[str]:
    domains = set()
    for s in strings:
        if DOMAIN_PATTERN.match(s.encode()):
            if len(s) > 4 and '.' in s:
                domains.add(s)
    return list(domains)[:50]


def _check_signing(apk_path: str) -> Dict[str, Any]:
    """
    Check for presence of signature files in the APK.
    Cannot verify signature validity without full verification tooling.
    """
    try:
        with zipfile.ZipFile(apk_path, 'r') as zf:
            names = zf.namelist()
            sig_files = [n for n in names if n.startswith("META-INF/") and
                        any(n.endswith(ext) for ext in [".RSA", ".DSA", ".EC", ".SF", ".MF"])]
            has_mf = any(n.endswith(".MF") for n in sig_files)
            has_sf = any(n.endswith(".SF") for n in sig_files)
            has_rsa = any(n.endswith((".RSA", ".DSA", ".EC")) for n in sig_files)

            cert_info = {}
            # Try to read certificate block info (very basic)
            for name in sig_files:
                if name.endswith((".RSA", ".DSA", ".EC")):
                    try:
                        data = zf.read(name)
                        cert_info["cert_file"] = name
                        cert_info["cert_size_bytes"] = len(data)
                        # Check for v2/v3 signing (presence of signing block between ZIP sections)
                        # This is a simplistic check only
                    except Exception:
                        pass

            return {
                "appears_signed": has_mf and has_sf and has_rsa,
                "sig_files": sig_files,
                "has_manifest": has_mf,
                "has_signature_file": has_sf,
                "has_cert_block": has_rsa,
                "cert_info": cert_info,
                "note": "Presence of signature files detected. Full cryptographic verification requires external tools (apksig, apktool).",
            }
    except Exception as e:
        return {"appears_signed": False, "error": str(e)}


def _list_native_libs(apk_path: str) -> Dict[str, List[str]]:
    libs: Dict[str, List[str]] = {}
    try:
        with zipfile.ZipFile(apk_path, 'r') as zf:
            for name in zf.namelist():
                if name.startswith("lib/") and name.endswith(".so"):
                    parts = name.split("/")
                    if len(parts) >= 3:
                        arch = parts[1]
                        lib_name = parts[2]
                        libs.setdefault(arch, []).append(lib_name)
    except Exception:
        pass
    return libs


def _list_assets(apk_path: str) -> List[str]:
    try:
        with zipfile.ZipFile(apk_path, 'r') as zf:
            return [n for n in zf.namelist() if n.startswith("assets/")][:30]
    except Exception:
        return []


# ── Main analysis entry point ─────────────────────────────────────────────────

def analyze_apk(apk_path: str) -> Dict[str, Any]:
    """
    Perform static, informational analysis of an APK file.
    Does NOT install, execute, or upload the APK.
    """
    path = Path(apk_path)

    if not path.exists():
        return {"error": f"File not found: {apk_path}"}
    if not path.suffix.lower() == ".apk":
        return {"error": "File does not have an .apk extension"}

    # Basic file info
    file_size = path.stat().st_size
    results: Dict[str, Any] = {
        "file_path": str(path.resolve()),
        "file_name": path.name,
        "file_size": file_size,
        "file_size_human": _human_size(file_size),
    }

    # Hashes
    try:
        results["hashes"] = file_hashes(apk_path)
    except Exception as e:
        results["hashes"] = {"error": str(e)}

    # Validate ZIP structure
    if not zipfile.is_zipfile(apk_path):
        results["error"] = "File is not a valid ZIP/APK archive"
        return results

    results["valid_zip"] = True

    # List APK contents
    try:
        with zipfile.ZipFile(apk_path, 'r') as zf:
            all_files = zf.namelist()
            results["file_count"] = len(all_files)
            results["has_classes_dex"] = any(n == "classes.dex" or n.startswith("classes") and n.endswith(".dex") for n in all_files)
            results["dex_files"] = [n for n in all_files if n.endswith(".dex")]
            results["has_resources"] = "resources.arsc" in all_files

            # Parse AndroidManifest.xml
            manifest_data = {}
            if "AndroidManifest.xml" in all_files:
                try:
                    raw_manifest = zf.read("AndroidManifest.xml")
                    parsed = _parse_manifest_xml(raw_manifest)
                    strings = parsed.get("strings", [])
                    permissions = _extract_permissions(strings)
                    pkg_name = _extract_package_name(strings)
                    version_info = _extract_version_info(strings)
                    embedded_domains = _extract_domains(strings)

                    manifest_data = {
                        "raw_parse_succeeded": parsed.get("raw_parse", False),
                        "package_name": pkg_name,
                        "version_name": version_info.get("version_name", ""),
                        "version_code": version_info.get("version_code", ""),
                        "permissions": permissions,
                        "high_risk_permissions": [p for p in permissions if p in HIGH_RISK_PERMISSIONS],
                        "domains_in_manifest": embedded_domains,
                        "parse_note": "Extracted from binary AXML. For complete manifest, use: aapt dump badging <file.apk>",
                    }
                except Exception as e:
                    manifest_data = {"error": str(e)}

            results["manifest"] = manifest_data

            # Scan all files for embedded URLs
            embedded_urls = set()
            for fname in all_files:
                if any(fname.endswith(ext) for ext in [".dex", ".xml", ".js", ".html", ".txt", ".json"]):
                    try:
                        data = zf.read(fname)
                        for url in URL_PATTERN.findall(data):
                            try:
                                decoded = url.decode('ascii', errors='ignore')
                                if len(decoded) > 10:
                                    embedded_urls.add(decoded)
                            except Exception:
                                pass
                    except Exception:
                        pass

            results["embedded_urls"] = list(embedded_urls)[:80]

    except Exception as e:
        results["zip_error"] = str(e)

    # Signing info
    results["signing"] = _check_signing(apk_path)

    # Native libraries
    results["native_libs"] = _list_native_libs(apk_path)

    # Assets
    results["assets"] = _list_assets(apk_path)

    # Risk assessment
    results["risk_summary"] = _build_risk_summary(results)

    return results


def _build_risk_summary(r: Dict[str, Any]) -> Dict[str, Any]:
    flags = []
    warnings = []

    manifest = r.get("manifest", {})
    high_risk = manifest.get("high_risk_permissions", [])
    all_perms = manifest.get("permissions", [])

    if high_risk:
        flags.append(f"{len(high_risk)} high-risk permission(s) requested")
    if len(all_perms) > 20:
        warnings.append(f"Large number of permissions ({len(all_perms)}) — review carefully")

    if not r.get("signing", {}).get("appears_signed"):
        flags.append("APK does not appear to be signed (no META-INF signature files found)")

    if len(r.get("dex_files", [])) > 3:
        warnings.append(f"Multiple DEX files ({len(r['dex_files'])}) — possible code obfuscation or large app")

    embedded = r.get("embedded_urls", [])
    http_urls = [u for u in embedded if u.startswith("http://")]
    if http_urls:
        warnings.append(f"{len(http_urls)} unencrypted HTTP URL(s) found embedded in the APK")

    native = r.get("native_libs", {})
    if native:
        lib_count = sum(len(v) for v in native.values())
        warnings.append(f"{lib_count} native library file(s) detected (cannot be statically analyzed here)")

    return {
        "flags": flags,
        "warnings": warnings,
        "disclaimer": (
            "This analysis is informational only. BReBon3S does not execute or install APKs. "
            "These findings cannot confirm an APK is safe or malicious. "
            "For authoritative analysis, submit to VirusTotal or Google Play Protect."
        ),
    }


def _human_size(size: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"
