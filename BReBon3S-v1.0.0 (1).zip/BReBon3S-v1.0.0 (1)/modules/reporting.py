"""
BReBon3S - Reporting Resources Module
Provides official abuse reporting links. Does NOT submit reports automatically.
"""

from typing import Any, Dict, List

# ── Official reporting resources ──────────────────────────────────────────────

REPORTING_RESOURCES: List[Dict[str, Any]] = [
    {
        "category": "Phishing & Malicious Websites",
        "resources": [
            {
                "name": "Google Safe Browsing — Report a phishing page",
                "url": "https://safebrowsing.google.com/safebrowsing/report_phish/",
                "description": (
                    "Report URLs you believe are phishing attempts targeting Google users. "
                    "Google reviews submissions and may add them to Safe Browsing blocklists "
                    "used by Chrome, Firefox, and other browsers."
                ),
                "what_to_report": "Phishing pages, fake login pages, credential-harvesting sites",
            },
            {
                "name": "Microsoft SmartScreen — Report an unsafe site",
                "url": "https://www.microsoft.com/en-us/wdsi/support/report-unsafe-site-guest",
                "description": (
                    "Report URLs to Microsoft's SmartScreen filter. Accepted reports are reviewed "
                    "and may be blocked in Microsoft Edge, Internet Explorer, and Windows Defender."
                ),
                "what_to_report": "Phishing sites, tech-support scam sites, malware distribution pages",
            },
            {
                "name": "PhishTank — Submit a suspected phish",
                "url": "https://www.phishtank.com/add_web_phish.php",
                "description": (
                    "Community-driven phishing URL database. Submitted URLs are voted on by the "
                    "community. Verified phish are added to the PhishTank feed used by many "
                    "security products."
                ),
                "what_to_report": "Phishing pages masquerading as legitimate services",
            },
            {
                "name": "Netcraft — Report cybercrime",
                "url": "https://report.netcraft.com/report",
                "description": (
                    "Netcraft accepts reports of phishing, malware, and fraudulent websites. "
                    "They have a track record of fast takedowns working with hosting providers."
                ),
                "what_to_report": "Phishing, pharming, fake shops, counterfeit sites",
            },
            {
                "name": "APWG eCrime Reporting — Phishing report",
                "url": "https://apwg.org/reportphishing/",
                "description": (
                    "The Anti-Phishing Working Group collects phishing reports and shares data "
                    "with law enforcement, security vendors, and industry partners."
                ),
                "what_to_report": "Phishing emails and phishing websites",
            },
        ],
    },
    {
        "category": "Malware & Harmful Apps",
        "resources": [
            {
                "name": "VirusTotal — Submit a file or URL",
                "url": "https://www.virustotal.com/gui/home/upload",
                "description": (
                    "Upload files or submit URLs for analysis against 70+ antivirus engines. "
                    "Reports are public. VirusTotal data feeds many security products. "
                    "Do not upload files containing sensitive personal data."
                ),
                "what_to_report": "Suspicious APKs, executables, scripts, or URLs",
            },
            {
                "name": "Google Play Protect — Report harmful app",
                "url": "https://support.google.com/googleplay/android-developer/answer/9888379",
                "description": (
                    "If you believe an app on Google Play is harmful, use the in-app 'Flag as "
                    "inappropriate' option on its Play Store listing, or contact Google Play support."
                ),
                "what_to_report": "Malicious, fraudulent, or policy-violating apps on Google Play",
            },
            {
                "name": "CISA Malware Report",
                "url": "https://www.cisa.gov/report",
                "description": (
                    "The Cybersecurity and Infrastructure Security Agency (CISA) accepts reports "
                    "of cyber incidents, malware, and vulnerabilities affecting US critical infrastructure."
                ),
                "what_to_report": "Significant malware incidents, critical infrastructure threats",
            },
        ],
    },
    {
        "category": "Fraud & Financial Scams",
        "resources": [
            {
                "name": "US FTC — Report fraud, scams, and identity theft",
                "url": "https://reportfraud.ftc.gov/",
                "description": (
                    "The Federal Trade Commission (FTC) investigates consumer fraud. Reports feed "
                    "the Consumer Sentinel Network used by law enforcement across the US. "
                    "You can report scams even if you lost no money."
                ),
                "what_to_report": "Online scams, imposter scams, fake prize schemes, identity theft",
            },
            {
                "name": "FTC — Identity Theft reporting",
                "url": "https://www.identitytheft.gov/",
                "description": (
                    "Dedicated FTC site for identity theft victims. Creates a personalised recovery "
                    "plan and official report you can provide to creditors and police."
                ),
                "what_to_report": "Identity theft resulting from data breaches or phishing",
            },
            {
                "name": "Action Fraud (UK) — Report fraud and cybercrime",
                "url": "https://www.actionfraud.police.uk/report-a-fraud",
                "description": (
                    "The UK's national reporting centre for fraud and cybercrime operated by the "
                    "City of London Police. Reports are assessed by the National Fraud Intelligence Bureau."
                ),
                "what_to_report": "Online fraud, investment scams, cybercrime (UK residents)",
            },
        ],
    },
    {
        "category": "Cybercrime & Internet Crime",
        "resources": [
            {
                "name": "FBI IC3 — Internet Crime Complaint Center",
                "url": "https://www.ic3.gov/",
                "description": (
                    "The FBI's Internet Crime Complaint Center (IC3) accepts complaints from US "
                    "victims of cybercrime. Analysts review complaints and refer cases to law "
                    "enforcement agencies. Reports are aggregated in the annual IC3 Crime Report."
                ),
                "what_to_report": "Ransomware, BEC scams, extortion, online fraud, data breaches",
            },
            {
                "name": "Europol — Report cybercrime (EU)",
                "url": "https://www.europol.europa.eu/report-a-crime/report-cybercrime-online",
                "description": (
                    "Europol provides links to national reporting portals for EU member states. "
                    "Cybercrime reports are coordinated with national law enforcement agencies."
                ),
                "what_to_report": "Cybercrime, online fraud, ransomware (EU residents)",
            },
            {
                "name": "NCSC — UK Suspicious Email Reporting Service",
                "url": "https://www.ncsc.gov.uk/collection/phishing-scams/report-scam-email",
                "description": (
                    "The UK National Cyber Security Centre runs the Suspicious Email Reporting Service "
                    "(SERS). Forward suspicious emails to report@phishing.gov.uk — NCSC analyses them "
                    "and can take down linked malicious sites."
                ),
                "what_to_report": "Phishing emails, smishing (SMS phishing), suspicious texts (UK)",
            },
        ],
    },
    {
        "category": "Child Safety & Illegal Content",
        "resources": [
            {
                "name": "NCMEC CyberTipline — Child exploitation",
                "url": "https://www.missingkids.org/gethelpnow/cybertipline",
                "description": (
                    "The National Center for Missing & Exploited Children (NCMEC) CyberTipline is "
                    "the congressionally-designated reporting mechanism for online child sexual "
                    "exploitation in the US. Reports are forwarded to law enforcement."
                ),
                "what_to_report": "Child sexual abuse material (CSAM), child exploitation",
            },
            {
                "name": "IWF — Internet Watch Foundation (UK)",
                "url": "https://www.iwf.org.uk/report/",
                "description": (
                    "The IWF works to remove online child sexual abuse content and provides a secure "
                    "anonymous reporting portal used internationally."
                ),
                "what_to_report": "Child sexual abuse material on websites, file hosting services",
            },
        ],
    },
    {
        "category": "Local Law Enforcement",
        "resources": [
            {
                "name": "Contact your local police",
                "url": "",
                "description": (
                    "For crimes where you are a direct victim — financial fraud, identity theft, "
                    "extortion, or threats — file a report with your local police department. "
                    "An official report number is often required by banks and insurers. "
                    "In the US, search 'police non-emergency number [your city]'. "
                    "In the UK, call 101 (non-emergency) or 999 (emergency). "
                    "In Australia, visit your nearest police station or call 131 444."
                ),
                "what_to_report": "Direct financial loss, identity theft, credible threats",
            },
        ],
    },
]

IMPORTANT_NOTICE = (
    "BReBon3S does NOT submit any report on your behalf. "
    "All links above go directly to official government or industry reporting pages. "
    "Always review what information you are submitting before sending any report. "
    "Providing false information to law enforcement agencies may be a criminal offence."
)


def get_all_resources() -> List[Dict[str, Any]]:
    return REPORTING_RESOURCES


def get_categories() -> List[str]:
    return [r["category"] for r in REPORTING_RESOURCES]


def get_resources_by_category(category: str) -> List[Dict[str, Any]]:
    for r in REPORTING_RESOURCES:
        if r["category"].lower() == category.lower():
            return r["resources"]
    return []


def search_resources(query: str) -> List[Dict[str, Any]]:
    """Search resources across all categories by keyword."""
    q = query.lower()
    matches = []
    for cat in REPORTING_RESOURCES:
        for res in cat["resources"]:
            if (q in res["name"].lower()
                    or q in res["description"].lower()
                    or q in res.get("what_to_report", "").lower()):
                matches.append({**res, "category": cat["category"]})
    return matches
