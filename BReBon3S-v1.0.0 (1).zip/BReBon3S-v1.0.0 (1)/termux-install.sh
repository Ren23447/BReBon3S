#!/data/data/com.termux/files/usr/bin/bash
# ╔══════════════════════════════════════════════════════════════════╗
# ║           BReBon3S — Termux Installation Script                 ║
# ║   Browser Recon & eBased Online Network Security Scanner        ║
# ║                        v1.0.0                                   ║
# ╚══════════════════════════════════════════════════════════════════╝
#
# Run this script inside Termux on your Android device.
# Usage:
#   chmod +x termux-install.sh
#   ./termux-install.sh
#
# This script will:
#   1. Update Termux package lists
#   2. Install all required system-level packages
#   3. Install all required Python packages via pip
#   4. Verify the installation works
#   5. Create a convenient launcher alias

set -e

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
WHITE='\033[1;37m'
NC='\033[0m'

banner() {
    echo ""
    echo -e "${CYAN}██████╗ ██████╗ ███████╗██████╗  ██████╗ ███╗   ██╗██████╗ ███████╗${NC}"
    echo -e "${CYAN}██╔══██╗██╔══██╗██╔════╝██╔══██╗██╔═══██╗████╗  ██║╚════██╗██╔════╝${NC}"
    echo -e "${CYAN}██████╔╝██████╔╝█████╗  ██████╔╝██║   ██║██╔██╗ ██║ █████╔╝███████╗${NC}"
    echo -e "${CYAN}██╔══██╗██╔══██╗██╔══╝  ██╔══██╗██║   ██║██║╚██╗██║ ╚═══██╗╚════██║${NC}"
    echo -e "${CYAN}██████╔╝██║  ██║███████╗██████╔╝╚██████╔╝██║ ╚████║██████╔╝███████║${NC}"
    echo -e "${CYAN}╚═════╝ ╚═╝  ╚═╝╚══════╝╚═════╝  ╚═════╝ ╚═╝  ╚═══╝╚═════╝ ╚══════╝${NC}"
    echo ""
    echo -e "${YELLOW}  Browser Recon & eBased Online Network Security Scanner${NC}"
    echo -e "${WHITE}  v1.0.0 — Termux Installer${NC}"
    echo ""
}

step() { echo -e "${CYAN}[•] $1${NC}"; }
ok()   { echo -e "${GREEN}  ✓ $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }
fail() { echo -e "${RED}  ✗ $1${NC}"; }

banner

# ── Detect Termux ─────────────────────────────────────────────────────────────
if [ ! -d "/data/data/com.termux" ]; then
    warn "This script is designed for Termux on Android."
    warn "If you are on Linux/macOS, use install.sh instead."
    echo ""
    read -rp "Continue anyway? [y/N] " ans
    [[ "$ans" =~ ^[Yy]$ ]] || exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 1 — Update Termux package lists
# ─────────────────────────────────────────────────────────────────────────────
step "Step 1/6 — Updating Termux package lists..."
echo -e "${YELLOW}  Note: If prompted to replace config files, press 'N' to keep existing.${NC}"
pkg update -y 2>&1 | tail -3
ok "Package lists updated"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 2 — Install system prerequisites
#
# Why each package is needed:
#   python       → Python 3 interpreter + pip
#   git          → Clone / update BReBon3S from GitHub
#   clang        → C compiler required to build Python packages with C extensions
#                  (e.g. lxml, cryptography, cffi)
#   libxml2      → XML parsing library — required to compile lxml
#   libxslt      → XSLT library — required to compile lxml
#   openssl      → TLS/SSL support for the `requests` and `ssl` modules
#   libffi       → Foreign Function Interface — required by `cffi` / `cryptography`
#   libc++       → C++ standard library — needed by some compiled extensions
#   rust         → Rust compiler — required by `cryptography` >= 3.4 on some archs
#                  (large install ~400 MB; skipped if already present)
# ─────────────────────────────────────────────────────────────────────────────
step "Step 2/6 — Installing required system packages..."

SYS_PACKAGES=(
    python
    git
    clang
    libxml2
    libxslt
    openssl
    libffi
    "libc++"
)

for pkg_name in "${SYS_PACKAGES[@]}"; do
    if pkg list-installed 2>/dev/null | grep -q "^${pkg_name}/"; then
        ok "Already installed: $pkg_name"
    else
        echo -e "  Installing: ${CYAN}$pkg_name${NC}"
        if pkg install -y "$pkg_name" 2>&1 | tail -2; then
            ok "Installed: $pkg_name"
        else
            warn "Could not install $pkg_name — continuing (may cause pip errors)"
        fi
    fi
done

# Check if Rust is available (needed for cryptography on some arm64 builds)
if ! command -v rustc &>/dev/null; then
    warn "Rust is not installed. If pip install fails on 'cryptography',"
    warn "run: pkg install rust   (warning: ~400 MB download)"
fi

# ─────────────────────────────────────────────────────────────────────────────
# STEP 3 — Upgrade pip and install wheel
# ─────────────────────────────────────────────────────────────────────────────
step "Step 3/6 — Upgrading pip and installing wheel..."
python3 -m pip install --upgrade pip wheel setuptools 2>&1 | tail -3
ok "pip, wheel, setuptools up to date"

# ─────────────────────────────────────────────────────────────────────────────
# STEP 4 — Install Python dependencies
#
# Why each package is needed:
#   rich         → The entire terminal UI (colors, panels, tables, progress bars)
#   colorama     → Cross-platform ANSI color support / initialization
#   requests     → HTTP requests for website fetching and API lookups
#   dnspython    → DNS record lookups (A, MX, TXT, DMARC, SPF, etc.)
#   beautifulsoup4 → HTML parsing for tracker, form, and script detection
#   lxml         → Fast HTML/XML parser backend for BeautifulSoup
#                  (optional — falls back to html.parser if unavailable)
# ─────────────────────────────────────────────────────────────────────────────
step "Step 4/6 — Installing Python packages..."

# Core packages (must succeed)
CORE_PACKAGES=("rich" "colorama" "requests" "dnspython" "beautifulsoup4")

for pypkg in "${CORE_PACKAGES[@]}"; do
    echo -e "  pip install ${CYAN}$pypkg${NC}"
    if python3 -m pip install "$pypkg" 2>&1 | tail -2; then
        ok "Installed: $pypkg"
    else
        fail "Failed to install $pypkg — check error above"
        exit 1
    fi
done

# Optional: lxml (faster HTML parser — requires libxml2/libxslt/clang)
echo ""
echo -e "  ${YELLOW}Attempting to install lxml (optional — needs clang + libxml2)...${NC}"
if python3 -m pip install lxml 2>&1 | tail -4; then
    ok "lxml installed — HTML parsing will be faster"
else
    warn "lxml could not be compiled. BReBon3S will fall back to html.parser."
    warn "This is normal on some devices and does not affect functionality."
    warn "To retry later: pkg install clang libxml2 libxslt && pip install lxml"
fi

# ─────────────────────────────────────────────────────────────────────────────
# STEP 5 — Set up data directory and verify imports
# ─────────────────────────────────────────────────────────────────────────────
step "Step 5/6 — Setting up data directory..."
mkdir -p "$SCRIPT_DIR/data"
if [ ! -f "$SCRIPT_DIR/data/reputation_db.json" ]; then
    echo '{"websites": {}, "apk_hashes": {}}' > "$SCRIPT_DIR/data/reputation_db.json"
    ok "Created local reputation database"
else
    ok "Reputation database already exists"
fi

step "Step 5/6 — Verifying all imports..."
cd "$SCRIPT_DIR"
if python3 -c "
import sys
sys.path.insert(0, '.')
from modules import ui, website, apk, database, reporting, settings, utils
print('All imports OK')
" 2>&1; then
    ok "All modules imported successfully"
else
    fail "Import check failed — see error above"
    echo ""
    echo -e "${YELLOW}Troubleshooting:${NC}"
    echo "  1. Make sure you cloned the full repo (not just individual files)"
    echo "  2. Run: git clone https://github.com/Ren23447/BReBon3S && cd BReBon3S"
    echo "  3. Re-run this script"
    exit 1
fi

# ─────────────────────────────────────────────────────────────────────────────
# STEP 6 — Create launcher alias
# ─────────────────────────────────────────────────────────────────────────────
step "Step 6/6 — Setting up launcher..."

# Create a launcher script
LAUNCHER="$SCRIPT_DIR/brebon3s"
cat > "$LAUNCHER" << LAUNCHEREOF
#!/data/data/com.termux/files/usr/bin/bash
cd "$SCRIPT_DIR"
python3 main.py "\$@"
LAUNCHEREOF
chmod +x "$LAUNCHER"
ok "Launcher script created: $LAUNCHER"

# Add alias to bashrc / zshrc if not already present
SHELL_RC="$HOME/.bashrc"
[ -f "$HOME/.zshrc" ] && SHELL_RC="$HOME/.zshrc"

ALIAS_LINE="alias brebon3s='python3 $SCRIPT_DIR/main.py'"
if ! grep -q "alias brebon3s=" "$SHELL_RC" 2>/dev/null; then
    echo "" >> "$SHELL_RC"
    echo "# BReBon3S alias" >> "$SHELL_RC"
    echo "$ALIAS_LINE" >> "$SHELL_RC"
    ok "Added 'brebon3s' alias to $SHELL_RC"
    ALIAS_ADDED=1
else
    ok "Alias 'brebon3s' already in $SHELL_RC"
fi

# ─────────────────────────────────────────────────────────────────────────────
# Done
# ─────────────────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║          BReBon3S installed successfully on Termux!          ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${WHITE}  How to run:${NC}"
echo -e "    ${CYAN}python3 $SCRIPT_DIR/main.py${NC}"
echo -e "    ${CYAN}./brebon3s${NC}"
if [ "${ALIAS_ADDED:-0}" = "1" ]; then
    echo -e "    ${CYAN}brebon3s${NC}   ← after running: source $SHELL_RC"
fi
echo ""
echo -e "${YELLOW}  DISCLAIMER: BReBon3S is for informational purposes only.${NC}"
echo -e "${YELLOW}  Passive analysis only — no exploitation, no root required.${NC}"
echo ""
