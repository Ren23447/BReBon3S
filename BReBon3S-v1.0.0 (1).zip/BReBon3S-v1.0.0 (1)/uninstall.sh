#!/usr/bin/env bash
# BReBon3S - Uninstaller script for Linux / macOS
# Usage: chmod +x uninstall.sh && ./uninstall.sh

set -e

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo -e "${CYAN}BReBon3S Uninstaller${NC}"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo -e "${YELLOW}This will remove the BReBon3S launcher script.${NC}"
echo -e "${YELLOW}Your local reputation database and config will be preserved unless you choose to delete them.${NC}"
echo ""

read -rp "Continue with uninstall? [y/N] " confirm
if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
    echo "Uninstall cancelled."
    exit 0
fi

# Remove launcher
if [ -f "$SCRIPT_DIR/brebon3s" ]; then
    rm "$SCRIPT_DIR/brebon3s"
    echo -e "${GREEN}  ✓ Removed launcher script${NC}"
fi

# Ask about data
echo ""
read -rp "Delete local database and config (data/ folder)? [y/N] " del_data
if [[ "$del_data" =~ ^[Yy]$ ]]; then
    if [ -d "$SCRIPT_DIR/data" ]; then
        rm -rf "$SCRIPT_DIR/data"
        echo -e "${GREEN}  ✓ Deleted data directory${NC}"
    fi
else
    echo -e "${YELLOW}  Database preserved at: $SCRIPT_DIR/data/${NC}"
fi

# Ask about pip packages
echo ""
read -rp "Uninstall Python dependencies (rich, colorama, requests, etc.)? [y/N] " del_deps
if [[ "$del_deps" =~ ^[Yy]$ ]]; then
    if command -v python3 &>/dev/null; then
        PYTHON_CMD="python3"
    else
        PYTHON_CMD="python"
    fi
    echo -e "${CYAN}Uninstalling pip packages...${NC}"
    $PYTHON_CMD -m pip uninstall -y rich colorama requests dnspython beautifulsoup4 lxml 2>/dev/null || true
    echo -e "${GREEN}  ✓ Dependencies removed${NC}"
fi

echo ""
echo -e "${GREEN}BReBon3S has been uninstalled.${NC}"
echo -e "${YELLOW}The project directory itself was not deleted: $SCRIPT_DIR${NC}"
echo ""
